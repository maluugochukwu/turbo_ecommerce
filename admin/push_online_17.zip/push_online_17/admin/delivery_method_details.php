<?php
include_once("libs/dbfunctions.php");
//var_dump($_SESSION);
$item_id         = $_REQUEST['item_id'];
$order_id        = $_REQUEST['order_id'];
$delivery_method = $_REQUEST['delivery_method'];

$sql = "SELECT * FROM orderdetails WHERE id = '$item_id'";


$dbobject = new dbobject();
$result = $dbobject->db_query($sql);
?>
   <div class="card">
    <div class="card-header">
        <h5 class="card-title"><?php echo ($delivery_method == "1")?"Customer Delivery Details":"Pickup Station Details"; ?></h5>
<!--        <h6 class="card-subtitle text-muted">The report contains orders that have not been attended to on time in the system.</h6>-->
    </div>
    <div class="card-body">
      
        <div id="datatables-basic_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
<!--
            <div class="row">
                <div class="col-sm-3">
                    <label for="">Create Role</label>
                </div>
            </div>
-->
            <div class="row">
                <div class="col-sm-12 table-responsive">
                    <table id="page_listwer" class="table table-striped " >
                        <thead>
                            <!-- <tr role="row">
                                <th>S/N</th>
                                <th>Contact Details</th>
                                <th>Type</th>
                                <th>Purpose</th>
                            </tr> -->
                        </thead>
                        <tbody>
                            <?php
                            if(count($result) > 0)
                            {
                                
                                if($delivery_method == "1")
                                {
                                    $location_det = $dbobject->getItemLabelArr('lga',array('Lgaid'),array($result[0]['customer_lga']),array('State','Lga'));
                                    $location_det = $location_det[0];
                                    echo  " <tr>
                                                <td>State/LGA</td>
                                                <td>".$location_det['State']." - ".$location_det['Lga']."</td>
                                            </tr>
                                            <tr>
                                                <td>Address</td>
                                                <td>".$result[0]['customer_address']."</td>
                                            </tr>
                                            <tr>
                                                <td>Phone Number</td>
                                                <td>".$result[0]['customer_phone_number']."</td>
                                            </tr>
                                            <tr>
                                                <td>First Name</td>
                                                <td>".$result[0]['customer_fname']."</td>
                                            </tr>
                                            <tr>
                                                <td>Last Name</td>
                                                <td>".$result[0]['customer_lname']."</td>
                                            </tr>
                                            ";
                                }else{
                                    $pickup  = $result[0]['pickup_station'];
                                    $ssql    = "SELECT * merchant_pickup_stores WHERE id = '$pickup' ";
                                    $rresult = $dbobject->db_query($ssql);
                                    $location_det = $dbobject->getItemLabelArr('lga',array('Lgaid'),array($rresult[0]['lga']),array('State','Lga'));
                                    $location_det = $location_det[0];
                                    echo  " <tr>
                                                <td>State/LGA</td>
                                                <td>".$location_det['State']." - ".$location_det['Lga']."</td>
                                            </tr>
                                            <tr>
                                                <td>Address</td>
                                                <td>".$rresult[0]['address']."</td>
                                            </tr>
                                            <tr>
                                                <td>Phone Number</td>
                                                <td>".$rresult[0]['office_phone']."</td>
                                            </tr>
                                            <tr>
                                                <td>Station Name</td>
                                                <td>".$rresult[0]['title']."</td>
                                            </tr>
                                            <tr>
                                                <td>Opening Hours</td>
                                                <td>".$rresult[0]['opening_hours_days']."</td>
                                            </tr>
                                            ";
                                }
                            }
                            else
                            {
                                echo "<tr><td colspan='4' align='center'>No address found</td></tr>";
                            }
                            
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--<script src="../js/sweet_alerts.js"></script>-->
<!--<script src="../js/jquery.blockUI.js"></script>-->
