<?php
include_once("libs/dbfunctions.php");

$dbobject = new dbobject();
//require 'vendor/autoload.php';
//
//use Carbon\Carbon;
//
////printf("Now: %s", Carbon::now());
//$now = Carbon::now();
//echo $now->copy()->diffForHumans(date('2020-08-26 01:12:00'));
//echo Carbon::createFromDate(1987, 05, 02)->age;
//echo $dbobject->time_elapsed_string('2020-08-26 01:12:00');
?>
  <style>
      .disa{
          
          color: #49505763
      }
      .disa:hover{
          cursor: not-allowed !important;
      }
    fieldset 
    { 
    display: block;
    margin-left: 2px;
    margin-right: 2px;
    padding-top: 0.35em;
    padding-bottom: 0.625em;
    padding-left: 0.75em;
    padding-right: 0.75em;
    border: 1px solid #ccc;
    }
    
    legend
    {
        font-size: 14px;
        padding: 5px;
        font-weight: bold;
    }
      .action_btn:hover{
          text-decoration: none
      }
      .dropdown{
          display: inline;
          float: left;
          
      }
      .action_btn:hover{
          color: crimson;
      }
</style>
   <div class="card">
    <div class="card-header">
        <h5 class="card-title"><i data-feather="sliders"></i>Orders List</h5>
        <h6 class="card-subtitle text-muted"><i class='align-middle mr-1' data-feather='user'></i> The report contains Orders for pending, confirmed,initialized, and fullfiled.</h6>
    </div>
    <div class="card-body">
         <fieldset >
            <legend style="padding:3px; padding-right:30px;padding-left:15px; width:auto; border:1px solid #eee; color:green"><i class="fa fa-filter"></i> Filter</legend>
            <div class="row">
                <div class="col-sm-2">
                 <label for="">Order Status</label>
                 <select id="order_status_filter" class="form-control">
                     <option value="">ALL</option>
                     <option value="0">PENDING</option>
                     <option value="1">CONFIRMED</option>
                     <option value="2">DECLINED</option>
                     
                     <option value="5">INITIATED</option>
                 </select>
                 </div>
                 
                 <div class="col-sm-2">
                     <label for="">Shipping Status</label>
                     <select id="shipping_filter" class="form-control">
                         <option value="">ALL</option>
                         <option value="0">NOT SHIPPED</option>
                         <option value="1">SHIPPED</option>
                         <option value="2">IN TRANSIT</option>
                         <option value="3">IN WAREHOUSE</option>
                         <option value="4">DELIVERED</option>
                     </select>
                 </div>
                 <div class="col-sm-2">
                     <label for="">Customer ID</label>
                     <input id="customer_filter" type="text" class="form-control">
                 </div>
                 <div class="col-sm-2">
                     <label for="">Order ID</label>
                     <input type="text" id="order_id_filter" class="form-control">
                 </div>
                 <div class="col-sm-2">
                     <label for="">Product Name</label>
                     <input type="text" id="product_name_filter" class="form-control">
                 </div>
                 <div class="col-sm-2">
                     <label for="">&nbsp;</label>
                     <button onclick="do_filter()" class="btn btn-block btn-success">Search</button>
                 </div>
            </div>
             
         </fieldset>
       <div class="row" style="margin-bottom:20px">
             
<!--
             <div class="col-sm-2">
             <a class="btn btn-warning" onclick="getModal('setup/delivery_location.php','modal_div')"  href="javascript:void(0)" data-toggle="modal" data-target="#defaultModalPrimary">Add a location</a>
         </div>
-->
         </div>
        <div id="datatables-basic_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
            <div class="row">
                <div class="col-sm-12 table-responsive">
                    <table id="page_list" class="table table-striped " >
                        <thead>
                            <tr role="row">
                                <th>S/N</th>
                                <th>Order ID</th>
                                <th>Product Name</th>
<!--                                <th>Selling Price</th>-->
                                <th>Quantity</th>
                                <th>Total Price</th>
                                <th>Order Status</th>
                                <th>Shipping Status</th>
                                <th>Customer ID</th>
                                <th>Delivery Method</th>
                                <th>Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../js/sweet_alerts.js"></script>
<!--<script src="../js/jquery.blockUI.js"></script>-->
<script>
  var table;
  var editor;
  var op = "Orders.orderSupportList";
  $(document).ready(function() {
    table = $("#page_list").DataTable({
      processing: true,
      columnDefs: [{
        orderable: false,
        targets: 0
      }],
        "order": [[ 9, 'asc' ]],
      serverSide: true,
      paging: true,
      oLanguage: {
        sEmptyTable: "No record was found, please try another query"
      },

      ajax: {
        url: "utilities.php",
        type: "POST",
        data: function(d, l) {
          d.op = op;
          d.li = Math.random();
          d.order_id_s    = $("#order_id_filter").val();
          d.order_status  = $("#order_status_filter").val();
          d.shipping_status   = $("#shipping_filter").val();
          d.product_name = $("#product_name_filter").val();
          d.customerid_s = $("#customer_filter").val();
//          d.end_date = $("#end_date").val();
        }
      }
    });
  });

  function do_filter() {
    table.draw();
  }
    function hide_div(el)
    {
        if(el.id == "branch_filter")
        {
            $("#churches_div").show();
            $("#region_div").hide();
            $("#filter").val(el.value);
        }else{
            $("#churches_div").hide();
            $("#region_div").show();
            $("#filter").val(el.value);
        }
    }
    
    function getModal(url,div)
    {
//        alert('dfd');
        $('#'+div).html("<h2>Loading....</h2>");
//        $('#'+div).block({ message: null });
        $.post(url,{},function(re){
            $('#'+div).html(re);
        })
    }
    function fetchLga(el)
    {
        $("#lga-fd").html("<option>Loading Lga</option>");
        $.post("utilities.php",{op:'Church.getLga',state:el},function(re){
//            $("#lga-fd").empty();
            console.log(re);
            $("#lga-fd").html(re.state);
            $("#church_id").html(re.church);
            
        },'json');
    }
    function changeOrderStatus()
    {
        
    }
  
    function shipOrder(customer_id,order_id,id)
    {
        var conf = confirm("Are you sure you want to take this action?");
        if(conf)
        {
            $.blockUI();
            var send_data = {op:'Orders.shipOrder', customer_id:customer_id, order_id:order_id, id:id};
            $.post('utilities.php',send_data, function(ree){
                console.log(ree);
                $.unblockUI();
                if(ree.responseCode == 0)
                {
                    swal({
                        text:ree.responseBody,
                        icon:"success"
                    })
                    getpage('order_list.php','page');
                }
                else
                {
                    swal({
                        text:ree.responseBody,
                        icon:"error"
                    })
                }
            },'json'
           )
        }
    }
    function order_in_transit(customer_id,order_id,id)
    {
        var conf = confirm("Are you sure you want to take this action?");
        if(conf)
        {
            $.blockUI();
            var send_data = {op:'Orders.orderInTransit', customer_id:customer_id, order_id:order_id, id:id};
            $.post('utilities.php',send_data, function(ree){
                console.log(ree);
                $.unblockUI();
                if(ree.responseCode == 0)
                {
                    swal({
                        text:ree.responseBody,
                        icon:"success"
                    })
                    getpage('order_list.php','page');
                }
                else
                {
                    swal({
                        text:ree.responseBody,
                        icon:"error"
                    })
                }
            },'json'
           )
        }
    }
    function order_in_warehouse(customer_id,order_id,id)
    {
        var conf = confirm("Are you sure you want to take this action?");
        if(conf)
        {
            $.blockUI();
            var send_data = {op:'Orders.orderInWarehouse', customer_id:customer_id, order_id:order_id, id:id};
            $.post('utilities.php',send_data, function(ree){
                console.log(ree);
                $.unblockUI();
                if(ree.responseCode == 0)
                {
                    swal({
                        text:ree.responseBody,
                        icon:"success"
                    })
                    getpage('order_list.php','page');
                }
                else
                {
                    swal({
                        text:ree.responseBody,
                        icon:"error"
                    })
                }
                
            },'json'
           )
        }
    }
    function order_delivered(customer_id,order_id,id)
    {
        var conf = confirm("Are you sure you want to take this action?");
        if(conf)
        {
            $.blockUI();
            var send_data = {op:'Orders.orderDelivered', customer_id:customer_id, order_id:order_id, id:id};
            $.post('utilities.php',send_data, function(ree){
                console.log(ree);
                $.unblockUI();
                if(ree.responseCode == 0)
                {
                    swal({
                        text:ree.responseBody,
                        icon:"success"
                    })
                    getpage('order_list.php','page');
                }
                else
                {
                    swal({
                        text:ree.responseBody,
                        icon:"error"
                    })
                }
            },'json'
           )
        }
    }
    function churchByState(el)
    {
        
        $.post("utilities.php",{op:'Church.churchByState',state:el},function(re){
//            $("#lga-fd").empty();
            console.log(re);
            $("#churches").empty();
            $("#churches").html(re);
            
        });
    }
    $(document).ready(function(){
        console.log($(".dropdown-menu .dropdown-item").text())
    })
    
</script>