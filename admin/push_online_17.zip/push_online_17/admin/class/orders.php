<?php

class Orders extends dbobject
{
    public function orderList($data)
    {
        $table_name    = "orderdetails";
		$primary_key   = "id";
		$columner = array(
			array( 'db' => 'id', 'dt' => 0),
            array( 'db' => 'orderid', 'dt' => 1),
            array( 'db' => 'product_name', 'dt' => 2),
            array( 'db' => 'quantity', 'dt' => 3),
            array( 'db' => 'total_price', 'dt' => 4),
            array( 'db' => 'order_status', 'dt' => 5,'formatter'=>function($d,$row){
                
                return $this->getOrderStatusString($d);
            }),
            array( 'db' => 'shipping_status', 'dt' => 6,'formatter'=>function($d,$row){
                
               $stattus = $this->getOrderShippingStatusString($d);
               if($stattus == "DELIVERED")
               {
                    return "<i class='fa fa-check-circle' style='color:green'></i> <span class='badge badge-info'>".$stattus."</span><div>".$this->time_elapsed_string($row['order_delivered_date'])."</div>";
               }else{
                   return $stattus;
               }
            }),
            array( 'db' => 'customerid', 'dt' => 7),
            array( 'db' => 'delivery_method', 'dt' => 8, 'formatter'=>function($d,$row){
                $item_id = $row['id'];
                $order_id = $row['orderid'];
                $delivery_method = $d;
                return ($d == 1)?"Door Delivery <button class='btn btn-info' onclick=\"getModal('delivery_method_details.php?item_id=$item_id&delivery_method=$delivery_method&order_id=$order_id','modal_div')\" href='javascript:void(0)' data-toggle='modal' data-target='#defaultModalPrimary'><i class='fa fa-user'></i> View Address</button>":"Pickup Station <button class='btn btn-info' onclick=\"getModal('delivery_method_details.php?item_id=$item_id&delivery_method=$delivery_method&order_id=$order_id','modal_div')\" href='javascript:void(0)' data-toggle='modal' data-target='#defaultModalPrimary'><i class='fa fa-home'></i> View Station</button> ";
            }),
            array( 'db' => 'order_delivered_date', 'dt' => 9,'formatter'=>function($d,$row){
                $d = $row['id'];
                $customer = $row['customerid'];
                $order    = $row['orderid'];
                $product  = $row['customerid'];
                $order_action_display = ($row['order_status'] == 0)?"block":"none";
                $shipping_action_display = ($row['order_status'] == 1 && $row['shipping_status'] != 4)?"block":"none";
                
                $shipped_state         = ($row['shipping_status'] == "1")?"fa-check-circle":"";
                $shipped_style         = ($row['shipping_status'] == "1")?"style='cursor:not-allowed; pointer-events:none; color:#49505763 '":"";
                $in_transit_state      = ($row['shipping_status'] == "2")?"fa-check":"";
                $in_transit_style         = ($row['shipping_status'] == "2")?"style='cursor:not-allowed; pointer-events:none; color:#49505763 '":"";
                $in_warehouse_state    = ($row['shipping_status'] == "3")?"fa-check":"";
                $in_warehouse_style         = ($row['shipping_status'] == "3")?"style='cursor:not-allowed; pointer-events:none; color:#49505763 '":"";
                $in_delivered_state    = ($row['shipping_status'] == "4")?"fa-check":"";
                $in_delivered_style         = ($row['shipping_status'] == "4")?"style='cursor:not-allowed; pointer-events:none; color:#49505763 '":"";
                return '<div class="dropdown" style="display:'.$order_action_display.'">
                                <a href="#" class="action_btn" data-toggle="dropdown" data-display="static" aria-expanded="false">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical align-middle "><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                                  Order Action 
                                  <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" onclick="declineOrder(\''.$customer.'\',\''.$order.'\',\''.$d.'\')" href="javascript:void(0)">Decline</a>
                                    <a class="dropdown-item" href="javascript:void(0)" onclick="confirmOrder(\''.$customer.'\',\''.$order.'\',\''.$d.'\')">Confirm</a>
                                    </div>
                                </a>   
                        </div>   <div class="dropdown" style="display:'.$shipping_action_display.'"><a href="#" class="action_btn" data-toggle="dropdown" data-display="static" aria-expanded="false">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical align-middle"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                                  Shipping Action
                                  <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item"  '.$shipped_style.' onclick="shipOrder(\''.$customer.'\',\''.$order.'\',\''.$d.'\')" href="javascript:void(0)"><i class="fa '.$shipped_state.'"></i> Shipped</a>
                                    <a class="dropdown-item" '.$in_transit_style.'  onclick="order_in_transit(\''.$customer.'\',\''.$order.'\',\''.$d.'\')" href="javascript:void(0)"><i class="fa '.$in_transit_state.'"></i> In Transit</a>
                                    <a class="dropdown-item" '.$in_warehouse_style.' onclick="order_in_warehouse(\''.$customer.'\',\''.$order.'\',\''.$d.'\')" href="javascript:void(0)"><i class="fa '.$in_warehouse_state.'"></i> In Warehouse</a>
                                    <a class="dropdown-item" '.$in_delivered_style.' onclick="order_delivered(\''.$customer.'\',\''.$order.'\',\''.$d.'\')" href="javascript:void(0)"><i class="fa '.$in_delivered_state.'"></i> Delivered</a>
                                    </div>
                                </a>   
                                </div> ';
            }),
            array( 'db' => 'createdon',  'dt' => 10 ),
            array( 'db' => 'orderid',  'dt' => 11,'formatter'=>function($d,$row){
                $customer = $row['customerid'];
                  $split_dist = "<button class='btn btn-info btn-block' onclick=\"getModal('transaction_details.php?order_id=$d&customer_id=$customer','modal_div2')\" href='javascript:void(0)' data-toggle='modal' data-target='#editing_product'>View Order Details</button>";
                  return $split_dist;
            } )
			);
		$filter = "";
		$filter .= ($_SESSION['role_id_sess']=="001")?"":" AND merchant_id='$_SESSION[merchant_sess_id]'";
		$filter .= " AND payment='1'";
//        $filter .= (isset($data['order_id']))?" AND orderid = '$data[order_id]' AND customerid = '$data[customerid]'":"";
        if(isset($data['order_id']) && $data['order_id'] != "")
        {
            $filter .= " AND orderid = '$data[order_id]'";
        }
        if(isset($data['customerid']) && $data['customerid'] != "")
        {
            $filter .= " AND customerid = '$data[customerid]'";
        }
        if(isset($data['order_status']) && $data['order_status'] != "")
        {
            $filter .= " AND order_status = '$data[order_status]'";
        }
        if(isset($data['shipping_status']) && $data['shipping_status'] != "")
        {
            $filter .= " AND shipping_status = '$data[shipping_status]'";
        }
        if(isset($data['product_name']) && $data['product_name'] != "")
        {
            $filter .= " AND product_name = '$data[product_name]'";
        }
        //@@@@@@@@@@@@@@@@ filter for transaction details  @@@@@@@@@@@@@@@@@@@@@@@@
        if(isset($data['order_id_s']) && $data['order_id_s'] != "")
        {
            $filter .= " AND orderid = '$data[order_id]'";
        }
        if(isset($data['customerid_s']) && $data['customerid_s'] != "")
        {
            $filter .= " AND customerid = '$data[customerid]'";
        }
		$datatableEngine = new engine();
		echo $datatableEngine->generic_table($data,$table_name,$columner,$filter,$primary_key);
    }
    public function orderSupportList($data)
    {
        $table_name    = "orderdetails";
		$primary_key   = "id";
		$columner = array(
			array( 'db' => 'id', 'dt' => 0),
            array( 'db' => 'orderid', 'dt' => 1),
            array( 'db' => 'product_name', 'dt' => 2),
            array( 'db' => 'quantity', 'dt' => 3),
            array( 'db' => 'total_price', 'dt' => 4),
            array( 'db' => 'order_status', 'dt' => 5,'formatter'=>function($d,$row){
                
                return $this->getOrderStatusString($d);
            }),
            array( 'db' => 'shipping_status', 'dt' => 6,'formatter'=>function($d,$row){
               $stattus = $this->getOrderShippingStatusString($d);
               if($stattus == "DELIVERED")
               {
                    return "<i class='fa fa-check-circle' style='color:green'></i> <span class='badge badge-info'>".$stattus."</span><div>".$this->time_elapsed_string($row['order_delivered_date'])."</div>";
               }else{
                   return $stattus;
               }
            }),
            array( 'db' => 'customerid', 'dt' => 7),
            array( 'db' => 'delivery_method', 'dt' => 8, 'formatter'=>function($d,$row){
                return ($d == 1)?"Door Delivery":"Pickup Station";
            }),
            array( 'db' => 'createdon',  'dt' => 9 ),
            array( 'db' => 'orderid',  'dt' => 10,'formatter'=>function($d,$row){
                $customer = $row['customerid'];
                  $split_dist = "<button class='btn btn-info btn-block' onclick=\"getModal('transaction_details.php?order_id=$d&customer_id=$customer','modal_div2')\" href='javascript:void(0)' data-toggle='modal' data-target='#editing_product'>View Order Details</button>";
                  return $split_dist;
            } )
			);
		$filter = "";
        if(isset($data['order_id']) && $data['order_id'] != "")
        {
            $filter .= " AND orderid = '$data[order_id]'";
        }
        if(isset($data['customerid']) && $data['customerid'] != "")
        {
            $filter .= " AND customerid = '$data[customerid]'";
        }
        if(isset($data['order_status']) && $data['order_status'] != "")
        {
            $filter .= " AND order_status = '$data[order_status]'";
        }
        if(isset($data['shipping_status']) && $data['shipping_status'] != "")
        {
            $filter .= " AND shipping_status = '$data[shipping_status]'";
        }
        if(isset($data['product_name']) && $data['product_name'] != "")
        {
            $filter .= " AND product_name = '$data[product_name]'";
        }
        //@@@@@@@@@@@@@@@@ filter for transaction details  @@@@@@@@@@@@@@@@@@@@@@@@
        if(isset($data['order_id_s']) && $data['order_id_s'] != "")
        {
            $filter .= " AND orderid = '$data[order_id]'";
        }
        if(isset($data['customerid_s']) && $data['customerid_s'] != "")
        {
            $filter .= " AND customerid = '$data[customerid]'";
        }
		$datatableEngine = new engine();
		echo $datatableEngine->generic_table($data,$table_name,$columner,$filter,$primary_key);
    }

    public function unattendedOrdersList($data)
    {
        $table_name    = "orderdetails";
		$primary_key   = "id";
		$columner = array(
			array( 'db' => 'id', 'dt' => 0 ),
			array( 'db' => 'TIMESTAMPDIFF(DAY,createdon,NOW()) AS delay', 'dt' => 1, 'formatter' => function( $d,$row ) {
						return $row['delay']." day(s) ago";
					} ),
			array( 'db' => 'merchant_id', 'dt' => 2, 'formatter' => function( $d,$row ) {
						return "<button class='btn btn-secondary' onclick=\"getModal('view_merchant_noti.php?merchant_id=$d','modal_div')\" href='javascript:void(0)' data-toggle='modal' data-target='#defaultModalPrimary'><i class='fa fa-home'></i> ".$this->getitemlabel('merchant_reg','merchant_id',$d,'merchant_name')."</button>";
					}  ),
			array( 'db' => 'orderid',  'dt' => 3 ),
			array( 'db' => 'order_status',  'dt' => 4, 'formatter' => function( $d,$row ) {
						return $this->getOrderStatusString($d);
					} ),
			array( 'db' => 'shipping_status',  'dt' => 5, 'formatter' => function( $d,$row ) {
						return $this->getShippingStatusString($d);
					} ),
			array( 'db' => 'product_name',  'dt' => 6 ),
			array( 'db' => 'quantity',  'dt' => 7 ),
			array( 'db' => 'total_price',  'dt' => 8 , 'formatter' => function( $d,$row ) {
						return "NGN ".number_format($d);
					} ),
			array( 'db' => 'createdon',     'dt' => 9, 'formatter' => function( $d,$row ) {
						return $d;
					}
				)
			);
		$filter = "";
		$filter = " AND payment='1'";
		$filter = " AND order_status='0'";
		$filter = " AND TIMESTAMPDIFF(DAY,createdon,NOW()) > 1";
		$datatableEngine = new engine();
	
		echo $datatableEngine->generic_table($data,$table_name,$columner,$filter,$primary_key);
    }
    public function delayedDelivery($data)
    {
        $table_name    = "orderdetails";
		$primary_key   = "id";
		$columner = array(
			array( 'db' => 'id', 'dt' => 0 ),
			array( 'db' => 'TIMESTAMPDIFF(DAY,order_confirmation_date,NOW()) AS delay', 'dt' => 1, 'formatter' => function( $d,$row ) {
						return $row['delay']." day(s) ago";
					} ),
			array( 'db' => 'merchant_id', 'dt' => 2, 'formatter' => function( $d,$row ) {
						return "<button class='btn btn-secondary' onclick=\"getModal('view_merchant_noti.php?merchant_id=$d','modal_div')\" href='javascript:void(0)' data-toggle='modal' data-target='#defaultModalPrimary'><i class='fa fa-home'></i> ".$this->getitemlabel('merchant_reg','merchant_id',$d,'merchant_name')."</button>";
					}  ),
			array( 'db' => 'orderid',  'dt' => 3 ),
            array( 'db' => 'order_status',  'dt' => 4, 'formatter' => function( $d,$row ) {
						return $this->getOrderStatusString($d);
					} ),
			array( 'db' => 'shipping_status',  'dt' => 5, 'formatter' => function( $d,$row ) {
						return $this->getShippingStatusString($d);
					} ),
			array( 'db' => 'product_name',  'dt' => 6 ),
			array( 'db' => 'quantity',  'dt' => 7 ),
			array( 'db' => 'total_price',  'dt' => 8 , 'formatter' => function( $d,$row ) {
						return "NGN ".number_format($d);
					} ),
			array( 'db' => 'createdon',     'dt' => 9, 'formatter' => function( $d,$row ) {
						return $d;
					}
				)
			);
		$filter = "";
		$filter = " AND payment = '1'";
		$filter = " AND order_status = '1'";
		$filter = " AND shipping_status <> '4'";
		$filter = " AND TIMESTAMPDIFF(DAY,order_confirmation_date,NOW()) > 7";
		$datatableEngine = new engine();
	
		echo $datatableEngine->generic_table($data,$table_name,$columner,$filter,$primary_key);
    }
    public function getOrderShippingStatusString($d)
    {
        if($d == 0)
        {
            return "NOT SHIPPED";
        }
        elseif($d == 1)
        {
            return "SHIPPED";
        }
        elseif($d == 2)
        {
            return "IN TRANSIT";
        }
        elseif($d == 3)
        {
            return "IN WAREHOUSE";
        }elseif($d == 4)
        {
            return "DELIVERED";
            
        }
    }
    public function sendOtp($data)
    {
        $customer_email =$data['customer_id'];
        $sql        = "SELECT first_name,last_name FROM userdata_customer WHERE email = '$customer_email' LIMIT 1";
        $result     = $this->db_query($sql);
        if(count($result) > 0)
        {
             $first_name = $result[0]['first_name'];
            $last_name  = $result[0]['last_name'];
            $merchant_name = $_SESSION['merchant_name_sess'];
            $token      = $this->generateToken();

            $sql        = "UPDATE userdata_customer SET purchase_token_auth ='$token', purchase_token_expire = DATE_ADD(NOW(), INTERVAL 10 MINUTE), purchase_token_count = '0' WHERE email = '$customer_email' LIMIT 1 ";
            $count = $this->db_query($sql,false);

            $body    = "Dear $first_name $last_name, <p>$merchant_name store is placing an order on your behalf, kindly provide only this 5 digit token <b style='font-size:18px'>$token</b> and nothing more to $merchant_name </p>";


    //        $notificationObj = new Notification();
    //        $templateObj     = new EmailTemplate();
    //        $message         = $templateObj->emailVerificationNew(array('title'=>'Transaction Verification','body'=>$body));
    //        $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>'VUVAA SHOP - TRANSACTION VERIFICATION','to'=>$customer_email,'message'=>$message));
            return json_encode(array('response_code'=>0,'response_message'=>'Token sent successfully','data'=>array('customer'=>$customer_email)));
        }
        else
        {
            return json_encode(array('response_code'=>11,'response_message'=>'<div style="color:red;font-weight:bold;margin-bottom:5px">Customer does not exist in our system</div>'));
        }
       
    }
    public function getOrderStatusString($code)
    {
         if($d == 0)
                {
                    return "PENDING CONFIRMATION";
                }elseif($d == 1)
                {
                    return "CONFIRMED";
                }
                elseif($d == 2)
                {
                    return "REJECTED";
                }
                elseif($d == 3)
                {
                    return "CANCELLED";
                }
                elseif($d == 4)
                {
                    return "CLOSED";
                }
                elseif($d == 5)
                {
                    return "INITIALIZED";
                }
    }
    public function getShippingStatusString($code)
    {
         if($d == 0)
        {
            return "NOT SHIPPED";
        }
        elseif($d == 1)
        {
            return "SHIPPED";
        }
        elseif($d == 2)
        {
            return "IN TRANSIT";
        }
        elseif($d == 3)
        {
            return "IN WAREHOUSE";
        }elseif($d == 4)
        {
            return "DELIVERED";
        }
    }
    public function verifyOtp($data)
    {
        $token = $data['token'];
        $sql = "SELECT username,purchase_token_expire FROM userdata_customer WHERE purchase_token_auth = '$token' LIMIT 1";
        $count = $this->db_query($sql,false);
        if($count > 0)
        {
            $sql = "SELECT TIMESTAMPDIFF(HOUR,NOW(),purchase_token_expire) AS t_diff_hr,TIMESTAMPDIFF(MINUTE,NOW(),purchase_token_expire) AS t_diff_min FROM userdata_customer WHERE purchase_token_auth = '$token'  LIMIT 1";
            $result = $this->db_query($sql);
            if(count($result) > 0)
            {
                if($result[0]['t_diff_min'] <= 0)
                {
                    return json_encode(array('response_code'=>77,'response_message'=>'<div style="color:red;font-weight:bold;margin-bottom:5px">Token has expired</div>'));
                }else
                {
                    return json_encode(array('response_code'=>0,'response_message'=>'Token is ok'));
                }
//                return $result[0]['t_diff_hr']." ".$result[0]['t_diff_min'];
            }
            else
            {
                return json_encode(array('response_code'=>77,'response_message'=>'<div style="color:red;font-weight:bold;margin-bottom:5px">something went wrong</div>'));
            }
        }else
        {
            return json_encode(array('response_code'=>77,'response_message'=>'<div style="color:red;font-weight:bold;margin-bottom:5px">invalid token</div>'));
        }
    }
    public function generateToken()
    {
        $chars = "0123456789";
        $res = "";
        for ($i = 0; $i < 5; $i++) 
        {
            $res .= $chars[mt_rand(0, strlen($chars)-1)];
        }
        $sql = "SELECT username FROM userdata_customer WHERE purchase_token_auth = '$res' LIMIT 1";
        $count = $this->db_query($sql,false);
        if($count > 0)
        {
            $this->generateToken();
        }else
        {
            return $res;
        }
    }
    
    private function packageOrderHtml($data)
    {
        $customer_id  = $data['customer_id'];
        $order_id     = $data['order_id'];
        $sql          = "SELECT * FROM orderdetails WHERE customerid = '$customer_id' AND orderid = '$order_id'";
        $result       = $this->db_query($sql);
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                
            }
        }
    }
    public function declineOrder($data)
    {
        $customer_id  = $data['customer_id'];
        $order_id     = $data['order_id'];
        $id   = $data['id'];
        $sql = "UPDATE orderdetails SET order_status = '2', order_rejected_date = NOW() WHERE customerid = '$customer_id' AND orderid = '$order_id' AND id = '$id'";
        $result = $this->db_query($sql,false);
        if($result >0)
        {
            $application_name = $_ENV['APPLICATION_NAME']; 
            $notificationObj = new Notification();
            $templateObj     = new EmailTemplate(); 
            $firstname       = $this->getitemlabel("userdata_customer","username",$customer_id,"first_name");
            $order_html      = $this->prepareHtmlSingleOrder($id);

            $email           = $customer_id;
            $message         = $templateObj->emailVerificationNew(array('title'=>'Order Declined','body'=>'<b>Hello '.$firstname.'!</b><p>Your Item (Item id: VUVORD-'.$id.'-ER), was declined. </p><h2 align="center">Item Details</h2>'.$order_html));
            $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>$application_name.': Order Declined','to'=>$email,'message'=>$message));
            return json_encode(array("responseCode"=>0,"responseBody"=>"Done"));
        }else
        {
            return json_encode(array("responseCode"=>62,"responseBody"=>"Could not update order"));
        }
    }
    public function confirmOrder($data)
    {
        $customer_id  = $data['customer_id'];
        $order_id     = $data['order_id'];
        $id            = $data['id'];
        
        $sql          = "UPDATE orderdetails SET order_status = '1', order_confirmation_date = NOW() WHERE customerid = '$customer_id' AND orderid = '$order_id' AND id = '$id'";
        $result = $this->db_query($sql,false);
        if($result >0)
        {
            $application_name = $_ENV['APPLICATION_NAME']; 
            $notificationObj = new Notification();
            $templateObj     = new EmailTemplate(); 
            $firstname       = $this->getitemlabel("userdata_customer","username",$customer_id,"first_name");
            $order_html      = $this->prepareHtmlSingleOrder($id);
            
            $email           = $customer_id;
            
            $message         = $templateObj->emailVerificationNew(array('title'=>'Order Confirmation','body'=>'<b>Hello '.$firstname.'!</b><p>Thank you for shopping on '.$application_name.'! Your item  has been successfully confirmed.</p><p>Your Item id: VUVORD-'.$id.'-ER. </p><b>Please note:</b><ul><li>If you ordered for multiple items, you may receive them on different days. This is because they are sold by different sellers on our platform and we want to make each item available to you as soon as possible after receiving it.</li></ul><h2 align="center">Item Details</h2>'.$order_html));
            $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>$application_name.': Order Confirmation','to'=>$email,'message'=>$message));
            
            return json_encode(array("responseCode"=>0,"responseBody"=>"Done"));
        }
        else
        {
            return json_encode(array("responseCode"=>62,"responseBody"=>"Could not update order"));
        }
    }
    public function shipOrder($data)
    {
        $customer_id  = $data['customer_id'];
        $order_id     = $data['order_id'];
        $id   = $data['id'];
        $sql = "UPDATE orderdetails SET shipping_status = '1', order_shipped_date = NOW() WHERE customerid = '$customer_id' AND orderid = '$order_id' AND id = '$id'";
        $result = $this->db_query($sql,false);
        if($result >0)
        {
            $application_name = $_ENV['APPLICATION_NAME']; 
            $notificationObj = new Notification();
            $templateObj     = new EmailTemplate(); 
            $firstname       = $this->getitemlabel("userdata_customer","username",$customer_id,"first_name");
            $order_html      = $this->prepareHtmlSingleOrder($id);
            
            $email           = $customer_id;
            $message         = $templateObj->emailVerificationNew(array('title'=>'Order Shipped','body'=>'<b>Hello '.$firstname.'!</b><p>Your Item (Item id: VUVORD-'.$id.'-ER), has been shipped. </p><p>Order ID: '.$order_id.'</p><h2 align="center">Item Details</h2>>'.$order_html));
            $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>$application_name.': Order Shipped','to'=>$email,'message'=>$message));
            return json_encode(array("responseCode"=>0,"responseBody"=>"Done"));
        }else
        {
            return json_encode(array("responseCode"=>62,"responseBody"=>"Could not update order"));
        }
    }
    public function orderInTransit($data)
    {
        $customer_id  = $data['customer_id'];
        $order_id     = $data['order_id'];
        $id   = $data['id'];
        $sql = "UPDATE orderdetails SET shipping_status = '2', order_transit_date = NOW() WHERE customerid = '$customer_id' AND orderid = '$order_id' AND id = '$id'";
        $result = $this->db_query($sql,false);
        if($result >0)
        {
            return json_encode(array("responseCode"=>0,"responseBody"=>"Done"));
        }else
        {
            return json_encode(array("responseCode"=>62,"responseBody"=>"Could not update order"));
        }
    }
    
    public function orderInWarehouse($data)
    {
        $customer_id  = $data['customer_id'];
        $order_id     = $data['order_id'];
        $id   = $data['id'];
        $sql = "UPDATE orderdetails SET shipping_status = '3', order_warehouse_processing_date = NOW() WHERE customerid = '$customer_id' AND orderid = '$order_id' AND id = '$id'";
        $result = $this->db_query($sql,false);
        if($result >0)
        {
            return json_encode(array("responseCode"=>0,"responseBody"=>"Done"));
        }else
        {
            return json_encode(array("responseCode"=>62,"responseBody"=>"Could not update order"));
        }
    }
    public function orderDelivered($data)
    {
        $customer_id  = $data['customer_id'];
        $order_id     = $data['order_id'];
        $id           = $data['id'];
        $sql = "UPDATE orderdetails SET shipping_status = '4', order_delivered_date = NOW() WHERE customerid = '$customer_id' AND orderid = '$order_id' AND id = '$id'";
        $result = $this->db_query($sql,false);
        if($result >0)
        {
            $application_name = $_ENV['APPLICATION_NAME']; 
            $notificationObj = new Notification();
            $templateObj     = new EmailTemplate(); 
            $firstname       = $this->getitemlabel("userdata_customer","username",$customer_id,"first_name");
            $order_html      = $this->prepareHtmlSingleOrder($id);

            $email           = $customer_id;
            $message         = $templateObj->emailVerificationNew(array('title'=>'Order Delivered','body'=>'<b>Hello '.$firstname.'!</b><p>Your Item (Item id: VUVORD-'.$id.'-ER), has just been delivered. </p><p>Order ID: '.$order_id.'</p><h2 align="center">Item Details</h2>'.$order_html));
            $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>$application_name.': Order Delivered','to'=>$email,'message'=>$message));
            return json_encode(array("responseCode"=>0,"responseBody"=>"Done"));
        }else
        {
            return json_encode(array("responseCode"=>62,"responseBody"=>"Could not update order"));
        }
    }
    public function generateOrderID($customerid)
    {
        $chars = "0123456789";
        $res = "";
        for ($i = 0; $i < 10; $i++) 
        {
            $res .= $chars[mt_rand(0, strlen($chars)-1)];
        }
        $sql = "SELECT orderid FROM orderdetails WHERE customerid = '$customerid' AND orderid = '$res' LIMIT 1";
        $count = $this->db_query($sql,false);
        if($count > 0)
        {
            $this->generateOrderID($customerid);
        }else
        {
            return $res;
        }
    }
    public function verifyOrderToken($data)
    {
        
    }
    public function fulfillOrder($data)
    {
        
    }
    public function updateOrder()
    {
        
    }
    public function updateShipping()
    {
        
    }
    public function prepareHtmlSingleOrder($id)
    {
        $sql    = "SELECT * FROM orderdetails WHERE id = '$id' LIMIT 1";
        $result = $this->db_query($sql);
        $contact = '<div class="yiv4670422568main" style="padding:0 0;">
                        <div class="yiv4670422568container" style="padding:0 0;">
                        
                        
                            <div class="yiv4670422568table" style="display:table;border-collapse:separate;width:100%;border-spacing:2px;">

                                <div class="yiv4670422568row" style="display:table-row;">
                                    <div class="yiv4670422568col yiv4670422568content" style="width:50%;display:table-cell;background-color:#fff;border:1px solid #ddd;border-collapse:collapse;vertical-align:top;">
                                        <p style="background-color:#f8f8f8;font-weight:bold;margin-top:0;margin-bottom:0px;padding:3px;vertical-align:middle;">Recipient details</p>
                                        <p style="padding-left:3px;margin-top:1px;">'.$result[0]['customer_fname'].' '.$result[0]['customer_phone_number'].'
                                        </p>
                                    </div>
                                    <div class="yiv4670422568col yiv4670422568content" style="width:50%;display:table-cell;background-color:#fff;border:1px solid #ddd;border-collapse:collapse;vertical-align:top;">
                                        <p style="background-color:#f8f8f8;font-weight:bold;margin-top:0;margin-bottom:0px;padding:3px;vertical-align:middle;">Delivery address</p>
                                        <p style="padding-left:3px;margin-top:1px;">'.$result[0]['customer_address'].' '.$this->getitemlabel('lga','Lgaid',$result[0]['customer_lga'],'Lga').' '.$this->getitemlabel('lga','Lgaid',$result[0]['customer_state'],'State').'
                                        </p>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>';
        
        
        $html   = '<table class="yiv4670422568orderinfotable" style="border:1px solid #ccc;margin:0;padding:0;width:100%;table-layout:fixed;">
                    <caption class="yiv4670422568orderinfocaption" style="font-weight:bold;text-align:left;padding-top:10px;">You ordered for:</caption>
                    <thead class="yiv4670422568orderinfohead" style="text-align:center;">
                        <tr class="yiv4670422568orderinfohead" style="background:#f8f8f8;border:1px solid #ddd;text-transform:uppercase;">
                            <th scope="col" style="width:15%;"></th>
                            <th scope="col" style="width:50%;">Item</th>
                            <th scope="col" style="width:15%;">Quantity</th>
                            <th scope="col" style="width:15%;">Price</th>
                        </tr>
                    </thead>
                    <tbody>';
        foreach($result as $row)
        {
            $img = $row[product_image];
            $html = $html.'<tr style="border:1px solid #ddd;text-align:center;"><td><img src="'.$img.'" style="width:50px; height:50px" width="50" height="50" /></td><td>'.$row[product_name].'</td><td>'.$row[quantity].'</td><td>'.$row[total_price].'</td></tr>';
        }
        $payment_method = $this->getitemlabel('transaction_table','order_id',$result[0]['orderid'],'payment_mode');
        $discount = ($row[0]['total_price'] == $result[0]['discount_price'])?0:($row[0]['total_price'] - $result[0]['discount_price']);
        $add_cost = '<table style="width:100%;border:1px solid #ccc;margin-top:5px;table-layout:auto;">
                    <tbody>
                    <tr>
                        <td style="font-weight:bold !important;text-transform:uppercase !important;">Amount</td>
                        <td style="text-align:right;">NGN '.$row[0]['total_price'].'</td>
                    </tr>
                   
                    
                   
                    <tr>
                        <td style="font-weight:bold !important;text-transform:uppercase !important;">Payment Method</td>
                        <td style="text-align:right;">
                            '.$payment_method.'
                        </td>
                    </tr>
                    </tbody>
                    </table>';
        
        return $html = $html."</tbody></table>".$add_cost;
    }
}