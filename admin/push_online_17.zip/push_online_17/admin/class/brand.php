<?php
// include_once("response.php");
// echo "hwao";
class Brand extends dbobject
{
    // private $response   = "";
    public function __construct()
    {
        // $this->response = new Response();
    }

    public function saveBrand($data)
    {
        $file_data = $data["_files"];
        $data['created']     = date("Y-m-d h:i:s");
        $data['merchant_id'] = $_SESSION['merchant_sess_id'];
        $data['posted_user'] = $_SESSION['username_sess'];
        $image_id   = date("Ymdhis");
        // var_dump($data);
        // return;

        if ($data['operation'] == "new") {
            $data["status"] = 1;
            $count   = $this->doInsert("brand", $data, array('operation', 'op', 'id', '_files'));
            if ($count > 0) {
                $sql = "SELECT id FROM brand ORDER BY id DESC LIMIT 1";
                $id = $this->db_query($sql);
                $id = $id[0]["id"];
                $path = $data['merchant_id'] . '/brand/';
                $ff = json_decode($this->saveMerchantImage($file_data, $data['merchant_id'], $path, $image_id), TRUE);
                $sql = "UPDATE brand SET image = '" . $ff["data"] . "' WHERE id = " . $id;
                // echo $sql."\n";
                $this->db_query($sql, false);
                return json_encode(array('response_code' => 0, 'response_message' => 'brand Created Successfully'));
            } else {
                return json_encode(array('response_code' => 47, 'response_message' => 'brand Creation Failed'));
            }
        } else {
            // var_dump($data);
            // return;
            $count   = $this->doUpdate("brand", $data, array('operation', 'op', '_files', 'created'), array('id' => $data['id']));
            if ($count > 0) {
                if(isset($data['_files']))
                {
                    $path = $data['merchant_id'] . '/brand/';
                    $ff = json_decode($this->saveMerchantImage($file_data, $data['merchant_id'], $path, $image_id), TRUE);
                    $sql = "UPDATE brand SET image = '" . $ff["data"] . "' WHERE id = " . $data["id"];
                    // echo $sql."\n";
                    $this->db_query($sql); 
                    return json_encode(array('response_code' => 0, 'response_message' => 'brand Updated Successfully'));
                }else
                {
                    return json_encode(array('response_code' => 0, 'response_message' => 'brand Updated Successfully'));
                }
                
                
            } else {
                return json_encode(array('response_code' => 47, 'response_message' => 'No update made'));
            }
        }
    }




    public function brandList($data)
    {
        $table_name    = "brand";
        $primary_key   = "id";
        $columner = array(
            array('db' => 'id', 'dt' => 0),
            array('db' => 'name', 'dt' => 1),
            array('db' => 'image', 'dt' => 2, 'formatter' => function ($d, $row) {
                // $product_name = $this->getitemlabel("products", "id", $d, "name");
                return "<img src='" . $d . "' width='50' height='50' class='img-thumbnail' />";
            }),
            array('db' => 'merchant_id',  'dt' => 3),

            array( 'db' => 'status',   'dt' => 4, 'formatter'=>function($id, $row){
                if($row['status'] == 0){
                    return "<span style='cursor:pointer' class='badge badge-danger'>INACTIVE</span>";
                }else {
                    return "<span style='cursor:pointer' class='badge badge-success'>ACTIVE</span>";
                }
            }),

            array('db' => 'created', 'dt' => 5, 'formatter' => function ($d, $row) {
                return $d;
            }),

            array('db' => 'id',  'dt' => 6, 'formatter' => function ($d, $row) {
                $status_result = $row["status"] != "1"? 'ACTIVATE' : 'DEACTIVATE';
                $lock = $status_result != "DEACTIVATE" ? "disabled": "";

                return '<a class="btn btn-warning dropdown-toggle" data-toggle="dropdown" href="#">
                            Action
                            <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item '.$lock.'" onclick="getModal(\'setup/brand_setup.php?op=edit&brand_id=' . $d . '\',\'modal_div\')"  href="javascript:void(0)" data-toggle="modal" data-target="#defaultModalPrimary">EDIT</a>
                            <a class="dropdown-item " onclick="changeBrandStatus('.$d.','.$row['status'].')" href="javascript:void(0)">'.$status_result.'</a>
                            <a class="dropdown-item '.$lock.'" onclick="deleteBrand('.$d.')" href="javascript:void(0)">DELETE</a>
                        </div>
                        ';

                // return '<a class="badge badge-warning" onclick="getModal(\'setup/brand_setup.php?op=edit&brand_id=' . $d . '\',\'modal_div\')"  href="javascript:void(0)" data-toggle="modal" data-target="#defaultModalPrimary">Edit Brand</a>';
            }),
        );
        $filter = "";
        // $filter = " AND merchant_id='$_SESSION[merchant_sess_id]'";
        $datatableEngine       = new engine();
        $resul                 = array();
        $resul['pointer'] = json_decode($datatableEngine->generic_table($data, $table_name, $columner, $filter, $primary_key),TRUE);
        echo json_encode($resul); 
    }

    public function getBrand($data)
    {
        $merchant_id = $_SESSION['merchant_sess_id'];
        $sql    = "SELECT * FROM brand WHERE status = 1";
        $result = $this->db_query($sql);
        $options = array();
        if (count($result) > 0) {
            foreach ($result as $row) {
                $options[] = array('id' => $row['id'], 'name' => $row['name'], 'merchant_id' => $row['merchant_id']);
            }
            return json_encode(array('responseCode' => 0, 'data' => $options));
        } else {
            return json_encode(array('responseCode' => 77, 'data' => ''));
        }
    }

    public function saveMerchantImage($data, $user_id, $path, $image_id = "")
    {
        $_FILES = $data;
        if (
            !isset($_FILES['upfile']['error']) ||
            is_array($_FILES['upfile']['error'])
        ) {
            return json_encode(array('response_code' => '74', 'response_mesage' => 'Invalid parameter.'));
        }

        // Check $_FILES['upfile']['error'] value.
        switch ($_FILES['upfile']['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_NO_FILE:
                return json_encode(array('response_code' => '74', 'response_mesage' => 'No file sent.'));
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return json_encode(array('response_code' => '74', 'response_mesage' => 'Exceeded filesize limit.'));
            default:
                return json_encode(array('response_code' => '74', 'response_mesage' => 'Unknown errors.'));
        }

        // You should also check filesize here.
        if ($_FILES['upfile']['size'] > 1000000) {
            return json_encode(array('response_code' => '74', 'response_mesage' => 'Exceeded filesize limit.'));
        }

        // DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!
        // Check MIME Type by yourself.
        //    $finfo = new finfo(FILEINFO_MIME_TYPE);
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if (false === $ext = array_search(
            finfo_file($finfo, $_FILES['upfile']['tmp_name']),
            array(
                'jpg' => 'image/jpeg',
                'png' => 'image/png'
            ),
            true
        )) {
            return json_encode(array('response_code' => '74', 'response_mesage' => 'Invalid file format.'));
        }

        // You should name it uniquely.
        // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!
        // On this example, obtain safe unique name from its binary data.
        $email = ($image_id == "") ? date('mdhis') : $image_id;

        // if (!move_uploaded_file(
        //     $_FILES['upfile']['tmp_name'],
        //     sprintf(
        //         $path . '%s.%s',
        //         $email,
        //         $ext
        //     )
        // )) {
        //     return json_encode(array('response_code' => '50', 'response_mesage' => 'Failed to move uploaded file.'));
        // }
        // $full_path = $path . $email . '.' . $ext;
        
        $s3Client = $this->createAwsS3($_ENV['AWS_ACCESS_KEY'],$_ENV['AWS_ACCESS_SECRET']);
                // echo "point1";
                $environment = ($_SERVER['SERVER_NAME'] == "store200.com")?"":"demo/";
        try {
            $result = $s3Client->putObject([
                'Bucket' => $_ENV['AWS_BUCKET'],
                'Key' => $environment.sprintf($path.'%s.%s',$email,$ext),
                'ContentLength' => $_FILES['upfile']['size'],
                'SourceFile' => $_FILES['upfile']['tmp_name'],
                // 'ACL'   => 'public-read'
            ]);
            // var_dump($result);
            $aws_full_path = $result['ObjectURL'];
            if (!filter_var($aws_full_path, FILTER_VALIDATE_URL))
            {
                return json_encode(array('response_code'=>'540','response_mesage'=>"Invalid url"));
            }
            
        } catch (AwsException $e) {
            // echo $e->getMessage();
            return json_encode(array('response_code'=>'540','response_mesage'=>$e->getMessage()));
        }
        //@@@@@@@@@@@@@@@@@@@@@@@@
        
        unlink($_FILES['upfile']['tmp_name']);
        return json_encode(array('response_code'=>'0','response_message'=>'success','data'=>$aws_full_path));


        // return json_encode(array('response_code' => '0', 'response_message' => 'success', 'data' => $full_path));
    }

    public function deleteBrand($data)
    {
        $brand_id = $data['brand_id'];
        $sql      = "DELETE FROM brand WHERE id = '$brand_id'";
        $cc = $this->db_query($sql, false);
        if ($cc) {
            return json_encode(array('response_code' => 0, 'response_message' => 'Action on product brand is now effective'));
        } else {
            return json_encode(array('response_code' => 432, 'response_message' => 'Action failed'));
        }
    }

    public function changeBrandStatus($data)
    {
        $brand_id = $data['brand_id'];
        $status   = ($data['current_status'] == 1) ? "0" : "1";
        $sql      = "UPDATE brand SET status = '$status' WHERE id = '$brand_id' LIMIT 1";
        $cc = $this->db_query($sql, false);
        if ($cc) {
            return json_encode(array('response_code' => 0, 'response_message' => 'Action on product brand is now effective'));
        } else {
            return json_encode(array('response_code' => 432, 'response_message' => 'Action failed'));
        }
    }
}
