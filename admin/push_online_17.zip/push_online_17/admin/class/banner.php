<?php
include_once("response.php");
class Banner extends dbobject
{
    private $response   = "";
    public function __construct()
    {
        $this->response = new Response();
    }
   
    public function saveBanner($data)
    {
//         var_dump($data);
        $file_data           = $data["_files"];
        $data['created']     = date("Y-m-d h:i:s");
        $data['merchant_id'] = $_SESSION['merchant_sess_id'];
        $data['posted_user'] = $_SESSION['username_sess'];
        $image_id            = date("Ymdhis");
//        if($data['is_carousel'] == "1")
//        {
//            $data['position'] = null;
//        }else
//        {
//            $data['carousel_position'] = null;
//        }
         $image_type = ($data['is_carousel'] == "1")?"carousel":"banner";
        if($data['operation'] == "new")
        {
                $data["id"] = date("Ymdhis");
                $Date       = date("Y-m-d");
                $duration   = $data['banner_duration'].' days';
                $data['expires_on'] = date('Y-m-d', strtotime($Date. ' + '.$duration));
                $count      = $this->doInsert("banner_table",$data,array('operation','op', '_files', 'image_location', 'u_type', 'upfile'));
//            echo $count."ghjkl;";
            if($count > 0)
            {
               
                $path = $data['merchant_id'].'/banner/';
                $ff = json_decode($this->saveMerchantImage($file_data,$data['merchant_id'],$path,$image_id,$image_type,$data['position']), TRUE);
                $sql = "UPDATE banner_table SET image = '".$ff["data"]."' WHERE id = ".$data["id"];
                // echo $sql."\n";
//                var_dump($ff);
                $this->db_query($sql,false);
                return json_encode(array('response_code'=>0,'response_message'=>'banner Created Successfully'));
            }
            else
            {
                return json_encode(array('response_code'=>47,'response_message'=>'banner Creation Failed'));
            }
        }
        else
        {
            // var_dump($data);
            // return;
            $data['modified']     = date("Y-m-d h:i:s");
            $count                = $this->doUpdate("banner_table",$data,array('operation','op','id', '_files', 'image_location', 'u_type', 'posted_user', 'upfile', 'created'),array('id'=>$data['id']));
            
            if($count > 0)
            {
                if(isset($data["_files"]))
                {
                    $path = $data['merchant_id'].'/banner/';
                    $ff = json_decode($this->saveMerchantImage($file_data,$data['merchant_id'],$path,$image_id,$image_type,$data['position']), TRUE);
                    $sql = "UPDATE banner_table SET image = '".$ff["data"]."' WHERE id = ".$data["id"];
                    // echo $sql."\n";
                    $this->db_query($sql,false);
                }
                
                return json_encode(array('response_code'=>0,'response_message'=>'banner Updated Successfully'));
            }
            else
            {
                return json_encode(array('response_code'=>47,'response_message'=>'No update made'));
            }
        }
    }
 
    
    
    
    public function bannerList($data)
    {
        $table_name    = "banner_table";
		$primary_key   = "id";
		$columner = array(
                array( 'db' => 'id', 'dt' => 0 ),
                array( 'db' => 'product_id', 'dt' => 1, 'formatter' => function( $d,$row ) {
                    $product_name = $this->getitemlabel("products", "id", $d, "name");
                    return $product_name;
                    }
                ),
                array( 'db' => 'image', 'dt' => 2, 'formatter' => function( $d,$row ) {
                    // $product_name = $this->getitemlabel("products", "id", $d, "name");
                    return "<img src='".$d."' width='50' height='50' class='img-thumbnail' />";
                    }
                ),
                array( 'db' => 'description',  'dt' => 3 ),
                array( 'db' => 'position',  'dt' => 4 ,'formatter'=>function($d,$row){
                    return ($row['is_carousel'] == '1')?$row['carousel_position']:$d;
                }),
                array( 'db' => 'is_carousel',  'dt' => 5,'formatter'=>function($d,$row){
                    return ($d == '1')?"YES":"NO";
                } ),
                array( 'db' => 'id',  'dt' => 6,'formatter' => function( $d,$row ) {
                            return '<a class="badge badge-warning" onclick="getModal(\'setup/banner_setup.php?op=edit&banner_id='.$d.'\',\'modal_div\')"  href="javascript:void(0)" data-toggle="modal" data-target="#defaultModalPrimary">Edit Banner</a> | <a class="badge badge-danger" onclick="deleteBanner(\''.$d.'\')"  href="javascript:void(0)" ><i class="fa fa-trash" ></i> Delete Banner</a>';
                        } ),
                array( 'db' => 'carousel_position', 'dt' => 7, 'formatter' => function( $d,$row ) {
//                            return $this->time_elapsed_string($d,false,"left");
//                            return $d;
                        }),
                       array( 'db' => 'created', 'dt' => 8, 'formatter' => function( $d,$row ) {
                            return $d;
                        }
                    )
			);
		$filter = "";
		$filter = " AND merchant_id='$_SESSION[merchant_sess_id]'";
		$datatableEngine = new engine();
	
		echo $datatableEngine->generic_table($data,$table_name,$columner,$filter,$primary_key);
    }
    public function deleteBanner($data)
    {
        $id     = $data['id'];
        $sql    = "DELETE FROM banner_table WHERE id = '$id' LIMIT 1";
        $count  = $this->db_query($sql,false);
        if($count > 0)
        {
            return json_encode(array('response_code'=>'0','response_mesage'=>'Banner deleted.'));
        }
        else
        {
            return json_encode(array('response_code'=>'77','response_mesage'=>'Banner could not be deleted.'));
        }
    }
    public function saveMerchantImage($data,$user_id,$path,$image_id,$image_type,$position)
    {
        $_FILES = $data;
        if (
            !isset($_FILES['upfile']['error']) ||
            is_array($_FILES['upfile']['error'])
        ) {
            return json_encode(array('response_code'=>'74','response_mesage'=>'Invalid parameter.'));
        }

        // Check $_FILES['upfile']['error'] value.
        switch ($_FILES['upfile']['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_NO_FILE:
                return json_encode(array('response_code'=>'74','response_mesage'=>'No file sent.'));
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return json_encode(array('response_code'=>'74','response_mesage'=>'Exceeded filesize limit.'));
            default:
                return json_encode(array('response_code'=>'74','response_mesage'=>'Unknown errors.'));
        }

        // You should also check filesize here.
        if ($_FILES['upfile']['size'] > 1000000) {
            return json_encode(array('response_code'=>'74','response_mesage'=>'Exceeded filesize limit.'));
        }

        // DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!
        // Check MIME Type by yourself.
    //    $finfo = new finfo(FILEINFO_MIME_TYPE);
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if (false === $ext = array_search(
            finfo_file($finfo,$_FILES['upfile']['tmp_name']),
            array(
                'jpg' => 'image/jpeg',
                'png' => 'image/png'
            ),
            true
        )) {
            return json_encode(array('response_code'=>'74','response_mesage'=>'Invalid file format.'));
        }

        // You should name it uniquely.
        // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!
        // On this example, obtain safe unique name from its binary data.
       $email = ($image_id == "")?date('mdhis'):$image_id;
        
        // if (!move_uploaded_file(
        //     $_FILES['upfile']['tmp_name'],
        //     sprintf($path.'%s.%s',
        //         $email,
        //         $ext
        //     )
        // )) {
        //     return json_encode(array('response_code'=>'50','response_mesage'=>'Failed to move uploaded file.'));
        // }
        $full_path = $_FILES['upfile']['tmp_name'];
        if($image_type == "carousel")
        {
            $myImage = new SimpleImage();
            $myImage->load($full_path);
            $myImage->resize(870,630);
//            $myImage->resize(289,509);
            $myImage->save($full_path);
            
        }else
        {
            if(in_array($position,array(2,5,6)))
            {
                $myImage = new SimpleImage();
                $myImage->load($full_path);
                $myImage->resize(261,372);
                $myImage->save($full_path); 
            }elseif(in_array($position,array(3,4)))
            {
                $myImage = new SimpleImage();
                $myImage->load($full_path);
                $myImage->resize(542,233);
                $myImage->save($full_path);
            }
            elseif(in_array($position,array(7,8)))
            {
                $myImage = new SimpleImage();
                $myImage->load($full_path);
                $myImage->resize(682,233);
                $myImage->save($full_path);
            }
            elseif($position == "1")
            {
                $myImage = new SimpleImage();
                $myImage->load($full_path);
                $myImage->resize(261,466);
                $myImage->save($full_path);
            }
        }

        $s3Client = $this->createAwsS3($_ENV['AWS_ACCESS_KEY'],$_ENV['AWS_ACCESS_SECRET']);
                // echo "point1";
                $environment = ($_SERVER['SERVER_NAME'] == "store200.com")?"":"demo/";
        try {
            $result = $s3Client->putObject([
                'Bucket' => $_ENV['AWS_BUCKET'],
                'Key' => $environment.sprintf($path.'%s.%s',$email,$ext),
                'ContentLength' => $_FILES['upfile']['size'],
                'SourceFile' => $_FILES['upfile']['tmp_name'],
                // 'ACL'   => 'public-read'
            ]);
            // var_dump($result);
            $aws_full_path = $result['ObjectURL'];
            if (!filter_var($aws_full_path, FILTER_VALIDATE_URL))
            {
                return json_encode(array('response_code'=>'540','response_mesage'=>"Invalid url"));
            }
            
        } catch (AwsException $e) {
            // echo $e->getMessage();
            return json_encode(array('response_code'=>'540','response_mesage'=>$e->getMessage()));
        }
        //@@@@@@@@@@@@@@@@@@@@@@@@
        
        unlink($_FILES['upfile']['tmp_name']);
        return json_encode(array('response_code'=>'0','response_message'=>'success','data'=>$aws_full_path));
        
    }
    
    // public function getBrand($data)
    // {
    //     $merchant_id = $_SESSION['merchant_sess_id'];
    //     $sql    = "SELECT * FROM brand WHERE merchant_id = '$merchant_id'";
    //     $result = $this->db_query($sql);
    //     $options = array();
    //     if(count($result) > 0)
    //     {
    //         foreach($result as $row)
    //         {
    //             $options[] = array('id'=>$row['id'],'name'=>$row['name'],'merchant_id'=>$row['merchant_id']);
    //         }
    //         return json_encode(array('responseCode'=>0,'data'=>$options));
    //     }
    //     else
    //     {
    //         return json_encode(array('responseCode'=>77,'data'=>''));
    //     }
        
    // }

    public function getProducts($data)
    {
        $category_id = $data['category_id'];
        $sql    = "SELECT * FROM products WHERE category_id='$category_id'";
        $result = $this->db_query($sql);
        $options = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $options[] = array('id'=>$row['id'],'name'=>$row['name'],'merchant_id'=>$row['merchant_id']);
            }
            return json_encode(array('responseCode'=>0,'data'=>$options));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'data'=>''));
        }
        
    }
  
}