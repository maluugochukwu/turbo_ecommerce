<?php
include_once("response.php");
class Category extends dbobject
{
    private $response   = "";
    public function __construct()
    {
        $this->response = new Response();
    }
   
    public function saveCategory($data)
    {
        $data['created'] = date("Y-m-d h:i:s");
        $data['merchant_id'] = $_SESSION['merchant_sess_id'];
        if($data['operation'] == "new")
        {
            
            $count   = $this->doInsert("product_categories",$data,array('operation','op','id','_files'));
            if($count > 0)
            {
                  $id = mysqli_insert_id($this->myconn);
                $file_data = $data['_files'];
                  $path = $data['merchant_id'] . '/category/';
                $ff = json_decode($this->saveMerchantImage($file_data, $data['merchant_id'], $path, ""), TRUE);
                $sql = "UPDATE product_categories SET image = '" . $ff["data"] . "' WHERE id = " . $id;
                $this->db_query($sql, false);
                return json_encode(array('response_code'=>0,'response_message'=>'Category Created Successfully '.$id));
            }else
            {
                return json_encode(array('response_code'=>47,'response_message'=>'Category Creation Failed'));
            }
        }else
        {
            $count   = $this->doUpdate("product_categories",$data,array('operation','op','id'),array('id'=>$data['id']));
            if(isset($data['_files']))
            {
                $id = $data['id'];
                $file_data = $data['_files'];
                  $path = $data['merchant_id'] . '/category/';
                $ff = json_decode($this->saveMerchantImage($file_data, $data['merchant_id'], $path, ""), TRUE);
                $sql = "UPDATE product_categories SET image = '" . $ff["data"] . "' WHERE id = " . $id;
                $this->db_query($sql, false);
            }
            if($count > 0)
            {
                
                
                return json_encode(array('response_code'=>0,'response_message'=>'Category Updated Successfully'));
            }else
            {
                $message = (isset($data['_files']))?"Picture uploaded successfully":"No update made";
                return json_encode(array('response_code'=>47,'response_message'=>$message));
            }
        }
    }
    
    public function deleteCategory($data)
    {
        $id = $data['id'];
        $sql     = "DELETE FROM product_categories WHERE id = '$id'";
        $this->db_query($sql,false);
        
        return json_encode(array('responseCode'=>0,'responseMessage'=>'SUCCESS'));
    }
    public function setFeatureStatus($data)
    {
        $status = $data['status'];
        $id = $data['id'];
        $sql = "UPDATE product_categories SET is_featured = '$status' WHERE id = $id LIMIT 1 ";
        $count = $this->db_query($sql,false);
        if($count > 0)
        {
            return json_encode(array('responseCode'=>0,'responseMessage'=>'SUCCESS'));
        }else
        {
            return json_encode(array('responseCode'=>33,'responseMessage'=>'nO UPDATE MADE'));
        }
        
    }
    public function categoryList($data)
    {
        $table_name    = "product_categories";
		$primary_key   = "id";
		$columner = array(
			array( 'db' => 'id', 'dt' => 0 ),
			array( 'db' => 'name',  'dt' => 1 ),
			array( 'db' => 'description',  'dt' => 2 ),
			array( 'db' => 'icon',  'dt' => 3, 'formatter' => function($d,$row){
                return "<i class='icon $d'></i>";
            } ),
            array( 'db' => 'image',  'dt' => 4, 'formatter' => function($d,$row){
                return "<image src='$d' width='50' height='50' class='img-thumbnail' />";
            } ),
			array( 'db' => 'is_featured',  'dt' => 5,'formatter' => function( $d,$row ) {
                $id = $row['id'];
                $feature_status = ($d == "1")?array("message"=>"Unfeature this category","class"=>"danger","value"=>0):array("message"=>"Feature this category","class"=>"primary","value"=>1);
						return '<a class="badge badge-warning" onclick="getModal(\'setup/category_setup.php?op=edit&cat_id='.$id.'\',\'modal_div\')"  href="javascript:void(0)" data-toggle="modal" data-target="#defaultModalPrimary">Edit Category</a> | <span style="cursor:pointer" onclick="setFeatureCat(\''.$feature_status['value'].'\',\''.$id.'\')" class="badge badge-'.$feature_status['class'].'">'.$feature_status['message'].'</span> | <a class="badge badge-danger" onclick="deleteCategory(\''.$id.'\')"  href="javascript:void(0)" >Delete Category</a>';
					} ),
			array( 'db' => 'created', 'dt' => 6, 'formatter' => function( $d,$row ) {
						return $d;
					}
				)
			);
		$filter = "";
//        $filter = " AND merchant_id='$_SESSION[merchant_sess_id]'";
		$datatableEngine = new engine();
	
		echo $datatableEngine->generic_table($data,$table_name,$columner,$filter,$primary_key);
    }
    public function saveMerchantImage($data, $user_id, $path, $image_id = "")
    {
        $_FILES = $data;
        if (
            !isset($_FILES['upfile']['error']) ||
            is_array($_FILES['upfile']['error'])
        ) {
            return json_encode(array('response_code' => '74', 'response_mesage' => 'Invalid parameter.'));
        }

        // Check $_FILES['upfile']['error'] value.
        switch ($_FILES['upfile']['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_NO_FILE:
                return json_encode(array('response_code' => '74', 'response_mesage' => 'No file sent.'));
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return json_encode(array('response_code' => '74', 'response_mesage' => 'Exceeded filesize limit.'));
            default:
                return json_encode(array('response_code' => '74', 'response_mesage' => 'Unknown errors.'));
        }

        // You should also check filesize here.
        if ($_FILES['upfile']['size'] > 1000000) {
            return json_encode(array('response_code' => '74', 'response_mesage' => 'Exceeded filesize limit.'));
        }

        // DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!
        // Check MIME Type by yourself.
        //    $finfo = new finfo(FILEINFO_MIME_TYPE);
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if (false === $ext = array_search(
            finfo_file($finfo, $_FILES['upfile']['tmp_name']),
            array(
                'jpg' => 'image/jpeg',
                'png' => 'image/png'
            ),
            true
        )) {
            return json_encode(array('response_code' => '74', 'response_mesage' => 'Invalid file format.'));
        }

        // You should name it uniquely.
        // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!
        // On this example, obtain safe unique name from its binary data.
        $email = ($image_id == "") ? date('mdhis') : $image_id;

        $s3Client = $this->createAwsS3($_ENV['AWS_ACCESS_KEY'],$_ENV['AWS_ACCESS_SECRET']);
                // echo "point1";
                $environment = ($_SERVER['SERVER_NAME'] == "store200.com")?"":"demo/";
        try {
            $result = $s3Client->putObject([
                'Bucket' => $_ENV['AWS_BUCKET'],
                'Key' => $environment.sprintf($path.'%s.%s',$email,$ext),
                'ContentLength' => $_FILES['upfile']['size'],
                'SourceFile' => $_FILES['upfile']['tmp_name'],
                // 'ACL'   => 'public-read'
            ]);
            // var_dump($result);
            $aws_full_path = $result['ObjectURL'];
            if (!filter_var($aws_full_path, FILTER_VALIDATE_URL))
            {
                return json_encode(array('response_code'=>'540','response_mesage'=>"Invalid url"));
            }
            
        } catch (AwsException $e) {
            // echo $e->getMessage();
            return json_encode(array('response_code'=>'540','response_mesage'=>$e->getMessage()));
        }
        //@@@@@@@@@@@@@@@@@@@@@@@@
        
        unlink($_FILES['upfile']['tmp_name']);
        return json_encode(array('response_code'=>'0','response_message'=>'success','data'=>$aws_full_path));
    }
    public function getCategory($data)
    {
        $merchant_id = $_SESSION['merchant_sess_id'];
//        $sql    = "SELECT * FROM product_categories WHERE merchant_id='$merchant_id'";
        $sql    = "SELECT * FROM product_categories ";
        $result = $this->db_query($sql);
        $options = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $options[] = array('id'=>$row['id'],'name'=>$row['name'],'merchant_id'=>$row['merchant_id']);
            }
            return json_encode(array('responseCode'=>0,'data'=>$options));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'data'=>''));
        }
        
    }
    public function getSubcategory($data)
    {
        $merchant_id = $_SESSION['merchant_sess_id'];
//        $sql    = "SELECT * FROM product_subcategory WHERE merchant_id='$merchant_id'";
        $sql    = "SELECT * FROM product_subcategory ";
        $result = $this->db_query($sql);
        $options = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $options[] = array('id'=>$row['id'],'name'=>$row['name'],'merchant_id'=>$row['merchant_id']);
            }
            return json_encode(array('responseCode'=>0,'data'=>$options));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'data'=>''));
        }
    }
    public function getProductsBySubcategory($data)
    {
        $merchant_id = $_SESSION['merchant_sess_id'];
        $subcat_id = $data['subcat_id'];
        $sql    = "SELECT * FROM products WHERE  sub_category = '$subcat_id'";
        $result = $this->db_query($sql);
        $options = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $options[] = array('id'=>$row['id'],'name'=>$row['name'],'merchant_id'=>$row['merchant_id']);
            }
            return json_encode(array('responseCode'=>0,'data'=>$options));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'data'=>''));
        }
    }
  
}