<?php
require_once 'shop.php';
class Checkout extends dbobject
{
    public $cartItem   = array();
    public $merchantID = "";
    public $customerID = "";
    public $onepayMerchantID = "";
    public $applicationName = "";
    
    public function __construct($merchant_id,$customer_id)
    {
        $this->merchantID = $merchant_id;
        $this->customerID = $customer_id;
        $this->onepayMerchantID = $_ENV['ONEPAY_MERCHANT_ID'];
        $this->applicationName = $_ENV['APPLICATION_NAME'];
    }
    public function logOrderTransaction($data,$application_id)
    {
//        var_dump($data);
        $shop     = new Shop("");
        //@@@@@@@@@@@@@@@@@  CHECK IF ACCOUNT HAS BEEN VERIFIED @@@@@@@@@@@@@@@@@@@@@@
//        echo $this->customerID;
        $result   = json_decode($shop->checkAccountVerificationStatus(array("email"=>$this->customerID)),TRUE);

        if($result["responseCode"] == "0")
        {
//            if($delivery_status['responseCode'] == "0")
//            {
                //            var_dump($data['product']);
            //@@@@@@@@@@@@@@@@@  VALIDATE DATA INPUT @@@@@@@@@@@@@@@@@@@@@@
            foreach($data['product'] as $row)
            {
                $validate = $this->validate($row,array('id'=>'required','quantity'=>'required'));
                if($validate['error'])
                {
                    return json_encode(array('responseCode'=>13,'responseMessage'=>$validate['messages'][0]));
                }
            }


            $validate = $this->validate($data['customer'],array('addressID'=>'required','transactionID'=>'required','deliveryMethod'=>'required'));
            if($validate['error'])
            {
                return json_encode(array('responseCode'=>13,'responseMessage'=>$validate['messages'][0]));
            }

            //@@@@@@@@@@@@@@@@@  CHECK WHAT IS IN THE USER CART @@@@@@@@@@@@@@@@@@@@@@
            
            $cart_status    = json_decode($this->checkCart($data['product']),TRUE);
//            var_dump($data);
            if($cart_status['responseCode'] != 0)
            {
                return json_encode($cart_status);
            }
            $app_id = $application_id;

            //@@@@@@@@@@@@@@@@@  CHECK THAT THE TRANSACTION ID OF THE APPLICATION IS UNIQUE @@@@@@@@@@@@@@@@@@@@@@
            $trans_status = $this->checkTransactionID($data['customer']['transactionID'],$app_id);
            if($trans_status['responseCode'] != 0)
            {
                echo json_encode($trans_status);
                exit();
            }
            $coupon_fee = 0;
            //@@@@@@@@@@@@@@@@@  IF THE USER ENTERED A COUPON CODE, VERIFY IT AND SET THE VALUE FOR THE COUPON @@@@@@@@@@@@@@@@@@@@@@
            if(trim($data['customer']['coupon']) != "")
            {
                $coupon_status = json_decode($this->validateCoupon($data['customer']['coupon']),TRUE);
                if($coupon_status['responseCode'] != 0)
                {
                    echo json_encode($coupon_status);
                    exit();
                }
                $coupon_fee = $coupon_status['responseBody']['coupons'][0]['value'];
            }
            $merchant_id    = $this->merchantID;
            $customerid     = $this->customerID;
            $coupon_code    = $data['customer']['coupon'];
            $address_id      = $data['customer']['addressID'];
            $delivery_method = $data['customer']['deliveryMethod'];
            $pickup_station = $data['customer']['pickupStation'];
            if($delivery_method == "2" && $pickup_station == "")
            {
                return json_encode(array("responseCode"=>447,"responseMessage"=>"Kindly select a pickup station"));
            }

            $sql = "SELECT * FROM customer_address WHERE id = '$address_id' LIMIT 1";
            $customer_data = $this->db_query($sql);
            if(count($customer_data) > 0)
            {
                $customer_address = $customer_data[0]['address'];
                $customer_state = $customer_data[0]['state'];
                $customer_lga = $customer_data[0]['lga'];
                $customer_f_name = $customer_data[0]['f_name'];
                $customer_l_name = $customer_data[0]['l_name'];
                $customer_phone_number = $customer_data[0]['phone_number'];
            }
            else
            {
                return json_encode(array("responseCode"=>821,"responseMessage"=>"Could not find customer address")); 
            }
            
            
            
            
//            $p_mode         = $_SERVER['REMOTE_ADDR'];
            $trans_id       = date("Ymdhis").rand(1,900);
            $application_transaction_id = $data['customer']['transactionID'];

            $order_id       = $this->generateOrderID($customerid);
            $cart_item      = $cart_status['responseBody']['cart'];
            $delivery_status   = json_decode($this->getDeliveryFee($cart_item,$customer_lga,$delivery_method),TRUE);
            
            
//            var_dump($order_id);
            if($delivery_status['responseCode'] == "0")
            {
                $shipping_fee   = $delivery_status['responseBody']['fee'];
                $amount         = $this->getCartTotal($cart_item);
                $total_quantity = $this->getTotalQuantity($cart_item);
                $total_amount   = $shipping_fee + ($amount - $coupon_fee);
                $createdon      = date('Y-m-d h:i:s');
                $desc           = "Payment for ".$total_quantity." item(s) from ".$this->getitemlabel("merchant_reg","merchant_id",$merchant_id,"merchant_name")." store";
                $p_mode         = "CARD";
                $posted_ip         = $_SERVER['REMOTE_ADDR'];

                $sql = "INSERT INTO transaction_table (transaction_id,order_id,transaction_amount,total_shipping_price,source_acct,destination_acct,transaction_desc,response_code,response_message,payment_mode,posted_ip,merchant_id,customer_id,customer_state,customer_lga,created,posted_user,application_transaction_id,application_id,pickup_station) VALUES('$trans_id','$order_id','$total_amount','$shipping_fee','$customerid','$merchant_id','$desc','99','Initialized','$p_mode','$posted_ip','$merchant_id','$customerid','$customer_state','$customer_lga','$createdon','$customerid','$application_transaction_id','$app_id','$pickup_station')";
                $count = $this->db_query($sql,false);

                if($count > 0)
                {
                    foreach($cart_item as $row)
                    {
                        $product_id             = $row['id'];
                        if($row['hasVariant'] == "1")
                        {
                            foreach($row['variant'] as $variant_row)
                            {
                                $quantity       = $variant_row['quantity'];
                                $price          = $variant_row['price'];
                                $variant_name   = $variant_row['name'];
                                $variant_price  = $variant_row['price'];
                                $variant_id     = $variant_row['id'];
                            }
                        }else
                        {
                            $quantity       = $row['quantity'];
                            $price          = $row['price'];
                            $variant_name   = "";
                            $variant_price  = "";
                            $variant_id  = "";
                        }
                        $profit                 = $row['profit'];
                        $total                  = $price * $quantity;
                        $payment                = 0;
                        $product_name           = $row['name'];
                        $product_description    = $row['description'];
                        $product_category       = $row['category'];
                        $sku_id                 = $row['sku_id'];
                        $image                  = $row['image'];
                        $has_variant            = $row['hasVariant'];
                        $merchant_id2           = $row['merchant']['id'];
                        
                        
                        
                       
                        $sql2 = "INSERT INTO orderdetails (orderid, product_id, customerid, quantity, discount_price, total_price, profit, createdon, payment, product_name, product_description, product_category_name, product_sku_id, product_image, merchant_id, has_variant, variant_name, variant_price,customer_state,customer_lga,customer_address,customer_phone_number,customer_fname,customer_lname,delivery_method,variant_id) VALUES('$order_id', '$product_id', '$customerid', '$quantity', '$price', '$total', '$profit', '$createdon', '$payment', '$product_name', '$product_description', '$product_category', '$sku_id', '$image', '$merchant_id2', '$has_variant', '$variant_name', '$variant_price','$customer_state','$customer_lga','$customer_address','$customer_phone_number','$customer_f_name','$customer_l_name','$delivery_method','$variant_id' )";
                        $orderquery = $this->db_query($sql2,false);
                    }
                    $grandTotal =  str_replace(",","",number_format($total_amount,2));
                    return json_encode(array("responseCode"=>0,"responseMessage"=>"Log operation was successful","responseBody"=>array("cartItem"=>$cart_item,"referenceID"=>$trans_id,"paymentGateway"=>array("merchantID"=>$this->onepayMerchantID),"grandTotal"=>$grandTotal)));
                }
                else
                {
                    return json_encode(array("responseCode"=>82,"responseMessage"=>"Could not save details at the moment. Please try later."));
                }
            }
            else
            {
                return json_encode($delivery_status);
            }
            
        }
        else
        {
            return json_encode($result);
        }
    }
    public function verifyPayment($data)
    {
        // if the transaction is successful and has not been treated then update the payment status on the orderdetails to 1 and the orderstatus to 0 then 
        
        $transid = $data['paymentReference'];
        $m_id    = substr($transid,9);
        $sql     = "SELECT is_treated,transaction_amount,order_id,customer_id,created,merchant_id FROM transaction_table WHERE transaction_id = '$m_id' LIMIT 1";
        $result  = $this->db_query($sql);
        $merchant_id = $result[0]['merchant_id'];
        if(count($result) > 0)
        {
            $curl = curl_init();
            $data = "MerchantRegID=".$this->onepayMerchantID."&MerchantTransID=".$transid;
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://www.onepay.com.ng/api/ValidateTrans/getTrans.php",
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_POSTREDIR => 3,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POSTFIELDS =>$data, 
                CURLOPT_CUSTOMREQUEST => "POST"
            ));

            $response = curl_exec($curl);
            $err      = curl_error($curl);

            curl_close($curl);

            if ($err) 
            {
              return json_encode(array('responseCode'=>67,'responseMessage'=>$err));

            } else 
            {
                $response = json_decode($response,TRUE);
                $code     = $response["data"]["response_code"];
                $message  = $response["data"]["response_message"];
                $amt      = $response["data"]["Amt_paid"];
                $payment_mode      = $response['data']['payment_gate'];
                $order_id = $result[0]['order_id'];
                
                
                $customer_email = $result[0]['customer_id'];
                $created = $result[0]['created'];
                $rr = "SELECT first_name, last_name FROM userdata_customer WHERE username = '$customer_email' LIMIT 1";
                $rr_result = $this->db_query($rr);
                $resp_messasge   = $message;
                if($result[0]['is_treated'] == "0")
                {
                    if($result[0]['transaction_amount'] == $amt)
                    {
                        
                        $sql = "UPDATE transaction_table SET response_code = '$code', payment_mode = '$payment_mode', response_message = '$message', is_treated = '1' WHERE transaction_id = '$m_id' LIMIT 1";
                        $count = $this->db_query($sql,false);
                        
                        if($count > 0)
                        {
                            if($code == "0")
                            {
                                // send email to merchant.
                                // send email to customer.
                                
                                $sql    = "UPDATE orderdetails SET payment = '1',order_status='0' WHERE orderid = '$order_id' AND customerid = '$customer_email'";
                                $count2 = $this->db_query($sql,false);
                                
                                $notificationObj = new Notification();
                                $templateObj     = new EmailTemplate(); 
                                $firstname       = $rr_result[0]['first_name'];
                                $lastname        = $rr_result[0]['last_name'];
                                
                                $email           = $customer_email;
                                $html_orders     = $this->prepareHtmlAllOrders($order_id,$customer_email);
                                
                                $message         = $templateObj->emailVerificationAPI(array('title'=>'Payment Receipt','body'=>'<b>Hello '.$firstname.' '.$lastname.'!</b><p>Thank you for using '.$this->applicationName.'. </p><h2 align="center">Transaction Summary</h2><table><tr><td><b>Transaction Ref:</b></td><td>'.$m_id.'</td></tr><tr><td><b>Order ID:</b></td><td>'.$order_id.'</td></tr> <tr><td><b>Amount:</b></td><td>'.$amt.'</td></tr> <tr><td><b>Date:</b></td><td>'.$created.'</td></tr> <tr><td><b>Status:</b></td><td>'.$resp_messasge.'</td></tr></table>'.$html_orders));
                                
                                // @@@@@@@@@@@@@@@@@@@ SEND EMAIL TO CUSTOMER @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                                $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>$this->applicationName.': Payment Recieved','to'=>$email,'message'=>$message));
                                
                                // @@@@@@@@@@@@@@@@@@@ SEND MAIL TO MERCHANT @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                                $this->purchaseNotificationEmail($order_id,$merchant_id);
                                
                                
                                // @@@@@@@@@@@@@@@@@@@ UPDATE COUPON @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                                $this->updateCouponUsed($m_id);
                                
                                $this->impactInventory($order_id,$customer_email);
                                
                                return json_encode(array('responseCode'=>$code,'responseMessage'=>$resp_messasge,"responseBody"=>array("orderID"=>$order_id,"customer"=>array("firstName"=>$firstname,"lastName"=>$lastname))));
                            }else
                            {
                                return json_encode(array('responseCode'=>$code,'responseMessage'=>$resp_messasge,"responseBody"=>array("orderID"=>$order_id)));
                            }
                            
                        }else
                        {
                            return json_encode(array('responseCode'=>890,'responseMessage'=>"Could not update this transaction","responseBody"=>array("orderID"=>$order_id)));
                        }
                    }else
                    {
                        return json_encode(array('responseCode'=>332,'responseMessage'=>"Underpaid or overpaid detected, kindly contact customer support.","responseBody"=>array("orderID"=>$order_id)));
                    }
                }else
                {
                    return json_encode(array('responseCode'=>$code,'responseMessage'=>$resp_messasge,"responseBody"=>array("orderID"=>$order_id,"customer"=>array("firstName"=>$firstname,"lastName"=>$lastname))));
                }
            }
        }else
        {
            return json_encode(array('responseCode'=>470,'responseMessage'=>"Invalid payment reference","responseBody"=>array("orderID"=>$order_id)));
        }
        
    }
    public function updateCouponUsed($transaction_id)
    {
      $sql    = "SELECT coupon_code,customer_id FROM transaction_table WHERE transaction_id = '$transaction_id' AND coupon_code IS NOT NULL LIMIT 1";  
      $result = $this->db_query($sql);
      if(count($result) > 0)
      {
        $coupon_code = $result[0]['coupon_code'];
        $customer_id = $result[0]['customer_id'];
        
        $sql    = "UPDATE coupon SET used_status = '1', used_by = '$customer_id', used_date = NOW(), transaction_id = '$transaction_id' WHERE id = '$coupon_code'";
        $count = $this->db_query($sql,false);
      }
        
    }
    public function impactInventory($order_id,$customer_id)
    {
        $sql = "SELECT * FROM orderdetails WHERE orderid = '$order_id' AND customerid = '$customer_id'";
        $result = $this->db_query($sql);
        $obj = array();
        
        foreach($result as $row)
        {
            $quantity   = $row['quantity'];
            $product_id = $row['product_id'];
            $has_variant = $row['has_variant'];
            $variant_id = $row['variant_id'];
            $customer_id = $row['customerid'];
            if($has_variant == "1")
            {
                $sql2 = "UPDATE product_variant SET inventory = inventory - $quantity WHERE track_inventory = '1' AND id = '$variant_id' LIMIT 1";
                $this->db_query($sql2,false);
            }else
            {
                $sql2 = "UPDATE products SET inventory = inventory - $quantity WHERE track_inventory = '1' AND id = '$product_id' LIMIT 1";
                $this->db_query($sql2,false);
            }
        }
    }
    public function checkCart($cart_item)
    {
        // check for duplicate product id in each object item
        foreach($cart_item as $row)
        {
            $id_check = $this->checkProductID($row);
            if($id_check["responseCode"] != 0) // SOMETHING IS NOT RIGHT WITH THE CART THE USER GAVE US
            {
                $this->cartItem = array(); // EMPTY WHATEVER HAS BEEN ADDED TO THE CART ARRAY
                return json_encode($id_check);
            }
        }
        return json_encode($id_check);
    }
    public function purchaseNotificationEmail($order_id,$merchant_id)
    {
        
        // get all the merchant that has the order id and send a mail to them, so foreach result send an email to the merchant
        $sql2    = "SELECT merchant_id FROM orderdetails WHERE orderid = '$order_id'";
        $result2 = $this->db_query($sql2);
        foreach($result2 as $row)
        {
            $merchant_id     = $row['merchant_id'];
            $sql             = "SELECT * FROM notification WHERE type = 'EMAIL' AND merchant_id = '$merchant_id' AND status = '1' AND purpose = 'PAID ORDERS' LIMIT 1 ";
            $result          = $this->db_query($sql);
            $notificationObj = new Notification();
            $templateObj     = new EmailTemplate();
            $merchant_name   = $this->getitemlabel('merchant_reg','merchant_id',$merchant_id,'merchant_name');
            $email           = $result[0]['address'];
            $html_orders = $this->prepareHtmlAllMerchantOrders($order_id,$merchant_id);
            $message         = $templateObj->emailVerificationAPI(array('title'=>'Payment Receipt','body'=>'<b>Hello '.$merchant_name.'!</b><p>We have just recieved a successful payment for the following order(s). </p>'.$html_orders));
            $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>$this->applicationName.': ORDER NOTIFICATION','to'=>$email,'message'=>$message));
        }
        
        
        
//        return $this->prepareHtmlAllOrders($order_id);
    }
    public function checkTransactionID($trans_id,$app_id)
    {
        $sql    = "SELECT transaction_id FROM transaction_table WHERE application_transaction_id = '$trans_id' AND application_id = '$app_id' LIMIT 1";
        $count  = $this->db_query($sql,false);
        if($count > 0)
        {
            return array("responseCode"=>56,"responseMessage"=>"Duplicate transaction detected!");
        }else
        {
            return array("responseCode"=>0,"responseMessage"=>"New transaction");
        }
    }
    public function getCartTotal($cart_item)
    {
        $amount = 0;
        foreach($cart_item as $row)
        {
            if($row['hasVariant'] == "1")
            {
                foreach($row['variant'] as $qes)
                {
                    $amount = $amount + ($qes['price'] * $qes['quantity']);
                }
            }
            else
            {
                $amount = $amount + ($row['price'] * $row['quantity']);
            }
        }
        return $amount;
    }
    public function getTotalQuantity($cart_item)
    {
        // check quantities for produts with variants
        $qty = 0;
        foreach($cart_item as $row)
        {
            if($row['hasVariant'] == "1")
                $qty = $qty + $row['variant']['quantity'];
            else
                $qty = $qty + $row['quantity'];
        }
        return $qty;
    }
    public function checkProductID($webCart)
    {
        $variant_arr = array();
        $merchant_id = $this->merchantID;
        
//        $sql         = "SELECT * FROM products WHERE id = '$webCart[id]' AND merchant_id = '$merchant_id' LIMIT 1";
        $sql         = "SELECT * FROM products WHERE id = '$webCart[id]'  LIMIT 1";
        $count       = $this->db_query($sql);
        if(count($count) > 0)
        {
            $product_name = $count[0]['name'];
            if($count[0]['visibility'] == "1")
            {
                if($count[0]['stock_status'] == "In Stock")
                {
                    if($count[0]['has_variant'] == "1" )
                    {
                        if(isset($webCart['variant']) && count($webCart['variant']) > 0)
                        {
                            foreach($webCart['variant'] as $variant_row)
                            {

                                $id          = $variant_row['id'];
//                                $sql         = "SELECT * FROM product_variant WHERE id = $id AND merchant_id = '$merchant_id' LIMIT 1";
                                $sql         = "SELECT * FROM product_variant WHERE id = $id  LIMIT 1";
                                $result      = $this->db_query($sql);
                                if(count($result) > 0)
                                {
                                    $variant_stock_status = $result[0]['stock_status'];
                                    $variant_visibility   = $result[0]['visibility'];
                                    if($result[0]['track_inventory'] == "1")
                                    {
                                        if($variant_row['quantity'] > $result[0]['inventory'])
                                        {
                                            return array("responseCode"=>88,"responseMessage"=>"The inventory for '".trim($result[0]['name'])."' variant is not sufficient for the quantity ordered.","responseBody"=>array("productID"=>$webCart[id],"variantID"=>$id));
                                        }else
                                        {
                                            $variant_profit = $result[0]['price'] - $count[0]['purchase_price'];
                                            $variant_arr[]  = array("id"=>$id,"price"=>$result[0]['price'],"name"=>$result[0]['name'],"quantity"=>$variant_row['quantity'],"profit"=>$variant_profit);
                                        }
                                    }else
                                    {
                                        if($variant_stock_status == "In Stock" && $variant_visibility == "1")
                                        {
                                            $variant_profit = $result[0]['price'] - $count[0]['purchase_price'];
                                            $variant_arr[]  = array("id"=>$id,"price"=>$result[0]['price'],"name"=>$result[0]['name'],"quantity"=>$variant_row['quantity'],"profit"=>$variant_profit);
                                        }
                                        else
                                        {
                                            return array("responseCode"=>88,"responseMessage"=>"This product variant '".trim($result[0]['name'])."' is either 'out of stock' or is not visible. visibility status=".$variant_stock_status,"responseBody"=>array("productID"=>$webCart[id],"variantID"=>$id));
                                        }
                                    }
                                }
                                else
                                {
                                    return array("responseCode"=>88,"responseMessage"=>"This product (".$product_name.")'s variant id was not found ","responseBody"=>array("productID"=>$webCart[id]));
                                }
                            } 
                        }else
                        {
                            return array("responseCode"=>88,"responseMessage"=>"This product '".$product_name."' requires a variant id and variant quantity","responseBody"=>array("productID"=>$webCart[id]));
                        }
                    }
                    else
                    {
                        if($count[0]['track_inventory'] == "1")
                        {
                            if($webCart['quantity'] > $count[0]['inventory'])
                            {
                                return array("responseCode"=>88,"responseMessage"=>"The inventory for '".$product_name."' product is not sufficient for the quantity ordered.","responseBody"=>array("productID"=>$webCart[id]));
                            }
                            else
                            {
                                // DO NOTHING HERE
                            }
                        }else
                        {
                            $product_stock_status = $count[0]['stock_status'];
                            $product_visibility   = $count[0]['visibility'];
                            if($product_stock_status == "In Stock" && $product_visibility == "1")
                            {
                                // DO NOTHING HERE
                            }
                            else
                            {
                                return array("responseCode"=>88,"responseMessage"=>"This product '".trim($count[0]['name'])."' is either 'out of stock' or is not visible.","responseBody"=>array("productID"=>$webCart[id]));
                            }
                        }
                    }
                    $purchase_price = $count[0]['purchase_price'];
                    $profit         = ($count[0]['has_variant'] == "1")?$variant_arr['price'] - $purchase_price:$count[0]['discount_price'] - $purchase_price;
                    
                    $name           = $count[0]['name'];
                    $description    = $count[0]['description'];
                    $category       = $count[0]['category_id'];
                    $sku_id         = $count[0]['sku_id'];
                    $shopObj        = new shop("");
//                    $image          = base64_encode(file_get_contents($shopObj->adminBaseUrl.str_replace("./","",$count[0]['image'])));
                    $image          = $count[0]['image'];
                    $total = 0;
                    if($count[0]['has_variant'] == "1")
                    {
                        foreach($variant_arr as $ops)
                        {
                            $total = $total + ($ops['price'] * $ops['quantity']);
                        }
                    }else
                    {
                        $total = $count[0]['discount_price']*$webCart['quantity'];
                    }
//                    $total          = ($count[0]['has_variant'] == "1")?$variant_arr['price'] * $webCart['quantity']:$count[0]['discount_price']*$webCart['quantity'];
                    $total          = str_replace(",","",number_format($total,2));
                    $merchant_name = $this->getitemlabel('merchant_reg','merchant_id',$count[0]['merchant_id'],"merchant_name");
                    
                    $this->cartItem[] = array("id"=>$webCart[id],"price"=>$count[0]['discount_price'],"quantity"=>$webCart['quantity'],"profit"=>$profit,"name"=>$name,"description"=>$description,"category"=>$category,"sku_id"=>$sku_id,"image"=>$image,"total"=>$total,"hasVariant"=>$count[0]['has_variant'],"variant"=>$variant_arr,"merchant"=>array('id'=>$count[0]['merchant_id'],'name'=>$merchant_name));
                    
                    return array("responseCode"=>0,"responseMessage"=>"Cart is clean","responseBody"=>array("cart"=>$this->cartItem));
                }else
                {
                    return array("responseCode"=>58,"responseMessage"=>"This product '".$product_name."' is out of stock","responseBody"=>array("productID"=>$webCart[id]));
                }
            }else
            {
                return array("responseCode"=>218,"responseMessage"=>"This product '".$product_name."' is no longer visible","responseBody"=>array("productID"=>$webCart[id]));
            }
        }else
        {
            return array("responseCode"=>87,"responseMessage"=>"This product was not found","responseBody"=>array("productID"=>$webCart[id]));
        }
    }
    public function validateCoupon($coupon_code)
    {
//        $sql = "SELECT * FROM coupon WHERE (customer_link = '$this->customerID' OR customer_link = '*') AND is_active = '1' AND used_status = '0' AND expire_date >= CURDATE() AND CURDATE() >= start_date AND merchant_id = '$this->merchantID' AND id ='$coupon_code' LIMIT 1  ";
        $sql = "SELECT * FROM coupon WHERE (customer_link = '$this->customerID' OR customer_link = '*') AND is_active = '1' AND used_status = '0' AND expire_date >= CURDATE() AND CURDATE() >= start_date AND  id ='$coupon_code' LIMIT 1  ";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            $coupons = array();
            foreach($result as $row)
            {
                $merchant_name = $this->getitemlabel("merchant_reg","merchant_id",$row['merchant_id'],"merchant_name");
                $forUseBy = ($row['customer_link'] == "*")?"All Customers":$row['customer_link'];
                $coupons[] = array("code"=>$row['id'],"name"=>$row['name'],"value"=>$row['value'],"expireDate"=>$row['expire_date'],"availableTo"=>$forUseBy,"merchant"=>array("id"=>$row['merchant_id'],"name"=>$merchant_name));
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Record Found","responseBody"=>array("coupons"=>$coupons)));
        }
        else
        {
            return json_encode(array("responseCode"=>99,"responseMessage"=>"Coupon code is invalid","responseBody"=>null));
        }
    }

    public function getOrderSummary()
    {
        
    }
    public function verifyCart($cart_item)
    {
        
    }
    public function apiGetDeliveryFee($cart_item,$shipping_destination,$delivery_method)
    {
        $cartcheck = json_decode($this->checkCart($cart_item),TRUE);
        if($cartcheck['responseCode'] == "0")
        {
            return $this->getDeliveryFee($this->cartItem,$shipping_destination,$delivery_method);
        }
        else
        {
            return json_encode($cartcheck);
        }
        
//        return json_encode(array("responseCode"=>0,"responseMessage"=>"OK","responseBody"=>array("fee"=>$fee)));
    }
    public function getDeliveryFee($cart_item,$shipping_destination,$delivery_method)
    {
        $fee= 0;
//        var_dump($cart_item);
        file_put_contents('film.txt',json_encode($cart_item));
        foreach($cart_item as $ee)
        {
            $shipping_cost = 0;
            $merchant_id = $ee['merchant']['id'];
            $sql         = "SELECT shipping_rule_type_id,id,lga_list,pickup_fee FROM shipping_regions WHERE  merchant_id = '$merchant_id' AND  FIND_IN_SET('$shipping_destination', lga_list) <> 0  ";
            file_put_contents('film_2.txt',$sql);
            $result      = $this->db_query($sql);
            if(count($result) > 0)
            {
                $id                   = $result[0]['id'];
                $rule_id               = $result[0]['shipping_rule_type_id'];
                $pickup_percentage_fee = $result[0]['pickup_fee'];
                // check if it's free or flat shipping
                if($rule_id == 1 || $rule_id == 4) // || $rule_id == 5
                {
                    $sql    = "SELECT shipping_fee FROM shipping_fee_prices WHERE shipping_region_id = '$id' AND merchant_id = '$merchant_id' LIMIT 1 ";
                    $result = $this->db_query($sql);
                    $db_fee = $result[0]['shipping_fee'];
//                    foreach($cart_item as $ee)
//                    {
                        $shipping_cost = $shipping_cost + $db_fee;
                        $shipping_cost = $shipping_cost * $ee['quantity'];
//                    }
                }
                else
                {
                    if($rule_id == 3)
                    {
//                        foreach($cart_item as $ee)
//                        {
                            if($ee['hasVariant'] == "1")
                            {
                                foreach($ee['variant'] as $row)
                                {
                                    $prod_price     = $row['price'];
                                
                                    $sql            = "SELECT shipping_fee FROM shipping_fee_prices WHERE $prod_price BETWEEN minimum_value AND maximum_value AND shipping_region_id = '$id' AND merchant_id = '$merchant_id' ";
                                    $result         = $this->db_query($sql);
                                    foreach($result as $row)
                                    {
                                        $shipping_cost  = $shipping_cost + $row['shipping_fee'];
                                    }
                                }
                            } 
                            else
                            {
                                $prod_price     = $ee['price'];
                                $sql            = "SELECT shipping_fee FROM shipping_fee_prices WHERE $prod_price BETWEEN minimum_value AND maximum_value AND shipping_region_id = '$id' AND merchant_id = '$merchant_id' ";
                                $result         = $this->db_query($sql);
                                foreach($result as $row)
                                {
                                    $shipping_cost  = $shipping_cost + $row['shipping_fee'];
                                }
                            }
                                
                            $shipping_cost = $shipping_cost * $ee['quantity'];
                            

//                        } 
                    }
                    if($rule_id == 2)
                    {
//                        foreach($cart_item as $ee)
//                        {
                            if($ee['hasVariant'] == "1")
                                $prod_weight     = $ee['variant']['weight'];
                            else
                                $prod_weight     = $ee['weight'];

                            $sql            = "SELECT shipping_fee FROM shipping_fee_prices WHERE $prod_weight BETWEEN minimum_value AND maximum_value AND shipping_region_id = '$id' AND merchant_id = '$merchant_id' ";
                            $result         = $this->db_query($sql);
                            foreach($result as $row)
                            {
                                $shipping_cost  = $shipping_cost + $row['shipping_fee'];
                            }
                            $shipping_cost = $shipping_cost * $ee['quantity'];
//                        } 
                    }
                }
                
                 $calfee = ($delivery_method == "2")?$shipping_cost - (($pickup_percentage_fee/100) * $shipping_cost):$shipping_cost;
                $fee = $fee + $calfee;
                $fee = str_replace(",","",number_format($fee,2));
            }else
            {
                return json_encode(array("responseCode"=>26,"responseMessage"=>"Merchant cannot deliver ".$ee['name']." to the region specified on your address","responseBody"=>array()));
            }
        }
        return json_encode(array("responseCode"=>0,"responseMessage"=>"OK","responseBody"=>array("fee"=>$fee)));
    }
    public function prepareHtmlAllOrders($order_id,$customer_id)
    {
        $sql    = "SELECT * FROM orderdetails WHERE orderid = '$order_id' AND customerid = '$customer_id'";
        $result = $this->db_query($sql);
        $html   = '<table style="border:1px solid #ccc;margin:0;padding:0;width:100%;table-layout:fixed;"><thead class="yiv4670422568orderinfohead" style="text-align:center;"><tr class="yiv4670422568orderinfohead" style="background:#f8f8f8;border:1px solid #ddd;text-transform:uppercase;"><td scope="col" style="width:15%;">Image</td><td scope="col" style="width:50%;">Name</td><td scope="col" style="width:15%;">Quantity</td></tr></thead>';
        foreach($result as $row)
        {
            $html = $html."<tr style='border:1px solid #ddd;text-align:center;'><td><img src='".$row[product_image]."' height='100' width='100' /></td><td>".$row[product_name]."</td><td>".$row[quantity]."</td></tr>";
        }
        return $html = $html."</table>";
    }
    public function prepareHtmlAllMerchantOrders($order_id,$merchant_id)
    {
        $sql    = "SELECT * FROM orderdetails WHERE orderid = '$order_id' AND merchant = '$merchant_id'";
        $result = $this->db_query($sql);
        $html   = '<table style="border:1px solid #ccc;margin:0;padding:0;width:100%;table-layout:fixed;"><thead class="yiv4670422568orderinfohead" style="text-align:center;"><tr class="yiv4670422568orderinfohead" style="background:#f8f8f8;border:1px solid #ddd;text-transform:uppercase;"><td scope="col" style="width:15%;">Image</td><td scope="col" style="width:50%;">Name</td><td scope="col" style="width:15%;">Quantity</td></tr></thead>';
        foreach($result as $row)
        {
            $html = $html."<tr style='border:1px solid #ddd;text-align:center;'><td><img src='".$row[product_image]."' style='width:50px; height:50px' width='50' height='50' /></td><td>".$row[product_name]."</td><td>".$row[quantity]."</td></tr>";
        }
        return $html = $html."</table>";
    }
    public function prepareHtmlSingleOrder($id)
    {
        $sql    = "SELECT * FROM orderdetails WHERE id = '$id' LIMIT 1";
        $result = $this->db_query($sql);
        $html   = '<table style="border:1px solid #ccc;margin:0;padding:0;width:100%;table-layout:fixed;"><thead class="yiv4670422568orderinfohead" style="text-align:center;"><tr class="yiv4670422568orderinfohead" style="background:#f8f8f8;border:1px solid #ddd;text-transform:uppercase;"><td scope="col" style="width:15%;">Image</td><td scope="col" style="width:50%;">Name</td><td scope="col" style="width:15%;">Quantity</td></tr></thead>';
        foreach($result as $row)
        {
            $html = $html."<tr style='border:1px solid #ddd;text-align:center;'><td><img src='".$row[product_image]."' style='width:50px; height:50px' width='50' height='50' /></td><td>".$row[product_name]."</td><td>".$row[quantity]."</td></tr>";
        }
        return $html = $html."</table>";
    }
    public function generateOrderID($customerid)
    {
        $chars = "0123456789";
        $yr    = date("Y");
        $res = "";
        for ($i = 0; $i < 8; $i++) 
        {
            $res .= $chars[mt_rand(0, strlen($chars)-1)];
        }
        $yr_chunck = str_split($yr);
        $res_chunck = str_split($res);
        // var_dump($yr_chunck); 
        $order_id = "";
        foreach($res_chunck as $key=> $val)
        {
            if($key == "2")
            {
                $order_id .= $yr_chunck[0].$val;
            }
            elseif($key == "4")
            {
                $order_id .= $yr_chunck[1].$val;
            }
            elseif($key == "6")
            {
                $order_id .= $yr_chunck[2].$val;
            }
            elseif($key == "1")
            {
                $order_id .= $yr_chunck[3].$val;
            }else
            {
                $order_id .= $val;
            }
        }
        $sql   = "SELECT orderid FROM oderdetails WHERE orderid = '$order_id' LIMIT 1";
        $count = $this->db_query($sql,false);
        if($count > 0)
        {
            $order_id = $this->generateOrderID($customerid);
        }
        return $order_id;
    }
}