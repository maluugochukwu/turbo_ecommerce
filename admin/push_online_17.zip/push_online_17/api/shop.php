<?php

use Ahc\Jwt\JWT;
class Shop extends dbobject
{
    public $merchantID       = "";
    public $customerID       = "";
    public $tokenSecretKey   = "";
    public $secretKeyEncryption = "";
    public $frontendBaseUrl = "";
    public $adminBaseUrl = "";
    public $applicationName = "";
    public function __construct($merchant_id)
    {
//        parent::__construct();
        $this->merchantID = $merchant_id;
        $this->tokenSecretKey   = $_ENV['TOKEN_SECRET_KEY'];
        $this->secretKeyEncryption = $_ENV['SECRET_KEY_ENCRYPTION'];
        $this->frontendBaseUrl = $_ENV['FRONTEND_BASE_URL'];
        $this->adminBaseUrl = $_ENV['APPLICATION_NAME'];
        $this->applicationName = $_ENV['APPLICATION_NAME'];
        
    }
   public function loadSettings($data)
   {
       $sql              = "SELECT industry,COUNT(merchant_id) as no_of_merchants FROM merchant_reg WHERE active_merchant = '1' GROUP BY industry";
       $result           = $this->db_query($sql);
       $merchantCategory = array();
       foreach($result as $row)
       {
           $name               = $this->getitemlabel("job_industry","id",$row['industry'],"name");
           $merchantCategory[] = array("id"=>$row['industry'],"name"=>$name,"merchantNumber"=>$row['no_of_merchants']);
       }
       $m                               = json_decode($this->getMerchants($data),TRUE);
       $merchants                       = ($m['responseCode']==0)?$m['responseBody']:null;
       $merchants["groupedCategories"]  = $merchantCategory;
       $sql = "SELECT * FROM advert WHERE expire_date > CURDATE() AND status = '1' LIMIT 5";
       $result = $this->db_query($sql);
       $advert = array();
       if(count($result) > 0)
       {
           foreach($result as $row)
           {
               $advert[] = array("merchantID"=>$row['merchant_id'], "imageURL"=>$row['banner_path'], "position"=>$row['position'], "type"=>$row['link_range'], "targetID"=>$row['target_id']);
           }
       }
       else
       {
           $advert = null;
       }
       $merchants["adverts"]            = $advert;
       return json_encode(array("responseCode"=>0,"responseMessage"=>"OK","responseBody"=>array("merchantInfo"=>$merchants)));
       
   }
    public function merchantDetails($data)
    {
        $merchant_id = $this->merchantID;
        $sql = "SELECT * FROM merchant_reg WHERE merchant_id = '$merchant_id' AND active_merchant = '1' LIMIT 1 ";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            $merchant = array();
            $categories = json_decode($this->getCategories(),TRUE);
            $brand = json_decode($this->getBrand(),TRUE);
            $brand = ($brand['responseBody'] == null)?null:$brand['responseBody']['brands'];
            $categories = ($categories['responseBody'] == null)?null:$categories['responseBody']['categories'];
            foreach($result as $row)
            {
                $merchant = array("name"=>$row['merchant_name'],"logo"=>$row['merchant_logo'],"address"=>$row['merchant_address'],"email"=>$row['merchant_email'],"phone"=>$row['merchant_phone'],"industryID"=>$row['industry']);
            }
            $merchant['product']['category'] = $categories;
            $merchant['product']['brand'] = $brand;
            $cc = json_decode($this->getPageSettings(),TRUE);
            $page = ($cc['responseCode'] == 0)?$cc['responseBody']['page']:null;
            return json_encode(array('responseCode'=>0,'responseMessage'=>"Successful",'responseBody'=>array('merchantInfo'=>$merchant,'pageSettings'=>$page)));
        }else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'Merchant not found or inactive','responseBody'=>null));
        }
    }
    public function getPageSettings()
    {
        $merchant_id = $this->merchantID;
        $sql         = "SELECT * FROM merchant_page_settings WHERE merchant_id = '$merchant_id' LIMIT 1";
        $result      = $this->db_query($sql);
//        var_dump($result);
        if(count($result) > 0)
        {
            $page = array();
            foreach($result as $row)
            {
                $page['primaryColor'] = $row['primary_color'];
                $page['secondaryColor'] = $row['secondary_color'];
                $page['menuFontColor'] = $row['menu_font_color'];
                $page['logoWidth'] = $row['logo_max_width'];
                $page['inlineTextLogo'] = ($row['text_logo_inline'] == 1)?true:false;
                $page['showMerchantName'] = ($row['show_display_name_logo'] == 1)?true:false;
            }
            return json_encode(array('responseCode'=>0,'responseMessage'=>"OK",'responseBody'=>array('page'=>$page)));
        }else
        {
            return json_encode(array('responseCode'=>13,'responseMessage'=>"OK",'responseBody'=>null));
        }
    }
    public function getCategoriesDetails($data)
    {
        $category_id = $data['categoryID'];
        $merchant_id = $this->merchantID;
        $sql         = "SELECT prd_c.id AS id,prd_c.name AS name,prd_c.icon icon,prd_c.image AS image,prd_c.is_featured AS featured FROM product_categories AS prd_c  WHERE merchant_id = '$merchant_id' AND id = '$category_id'  ";
        $result = $this->db_query($sql);
        $cat = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $is_featured = ($row['featured'] == "1")?true:false;
                $cat[] = array("id"=>$row['id'],"name"=>$row['name'],'icon'=>$row['icon'],'image'=>$row['image'],'isFeatured'=>$is_featured);
            }
            return json_encode(array('responseCode'=>0,'responseMessage'=>"OK",'responseBody'=>array('category'=>$cat)));
        }
        else
        {
            return json_encode(array('responseCode'=>134,'responseMessage'=>"No category found",'responseBody'=>null));
        }
    }
    public function getSubcategoriesDetails($data)
    {
        $category_id = $data['subcategoryID'];
        $merchant_id = $this->merchantID;
        $sql3       = "SELECT * FROM product_subcategory WHERE id = '$category_id' AND merchant_id='$merchant_id' ";
        $cat_result = $this->db_query($sql3);
        $options = array();
        if(count($cat_result) > 0)
        {
            foreach($cat_result as $row3)
            {
                $options[]   = array("id"=>$row3['id'],"name"=>$row3['name']);
            }
            return json_encode(array('responseCode'=>0,'responseMessage'=>"OK",'responseBody'=>array('subcategory'=>$options)));
        }else
        {
            return json_encode(array('responseCode'=>114,'responseMessage'=>"No subcategory found",'responseBody'=>null));
        }
        
    }
    public function getCategories()
    {
        $merchant_id = $this->merchantID;
        
        $sql    = "SELECT prd_c.id AS id,prd_c.name AS name,prd_c.icon icon,prd_c.image AS image,prd_c.is_featured AS featured FROM product_categories AS prd_c  WHERE merchant_id='$merchant_id'  ";
        $result = $this->db_query($sql);
        
        
        $cat = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $headers = array();
                $cat_id     = $row['id'];
                $sql2       = "SELECT * FROM product_subcategory WHERE category_id = '$cat_id' AND is_parent = '1' AND merchant_id='$merchant_id' ";
                $cat_header_result = $this->db_query($sql2);
                
                foreach($cat_header_result as $row2)
                {
                    $options = array();
                    $group_id = $row2['id'];
                     $sql3       = "SELECT * FROM product_subcategory WHERE category_id = '$cat_id' AND is_parent = '0' AND parent_id = '$group_id' AND merchant_id='$merchant_id' ";
                    $cat_result = $this->db_query($sql3);
                    foreach($cat_result as $row3)
                    {
                        $options[]   = array("id"=>$row3['id'],"name"=>$row3['name']);
                    }
                    $headers[]   = array("id"=>$row2['id'],"name"=>$row2['name'],"subGroup"=>$options);
                }
                $is_featured = ($row['featured'] == "1")?true:false;
                $cat[] = array("id"=>$row['id'],"name"=>$row['name'],'icon'=>$row['icon'],'image'=>$row['image'],'isFeatured'=>$is_featured,"group"=>$headers);
            }
            return json_encode(array('responseCode'=>0,'responseMessage'=>"Successful",'responseBody'=>array('categories'=>$cat)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
        }
    }
    
    public function getBrand()
    {
        $merchant_id = $this->merchantID;
        $sql    = "SELECT * FROM brand WHERE merchant_id='$merchant_id'";
        $result = $this->db_query($sql);
        $options = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $options[] = array('id'=>$row['id'],'name'=>$row['name'],'image'=>$row['image']);
            }
            return json_encode(array('responseCode'=>0,'responseMessage'=>"Successful",'responseBody'=>array('brands'=>$options)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
        }
    }
    public function getMerchantID($data)
    {
        $merchant_name = $data['merchantName'];
        $sql = "SELECT merchant_id FROM merchant_reg WHERE merchant_name = '$merchant_name' LIMIT 1";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            $merchant_id = $result[0]['merchant_id'];
            return json_encode(array('responseCode'=>0,'responseMessage'=>"Successful",'responseBody'=>array('merchantID'=>$merchant_id)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'Merchant not found','responseBody'=>null));
        }
    }
    public function productSearch($data)
    {
        $merchant_id = $this->merchantID;
        $text        = $data['searchString'];
        $startLimit  = ($data['pageNo'] - 1) * $data['recordsPerRequest'];
        $filter      = ($data['using'] == "app")?"":" AND products.merchant_id = '$merchant_id'";
        $char_length = strlen($text);
        if($char_length > 1)
        {
           $sql         = "SELECT  inventory, stock_status, discounted_percentage, discount_price, price,products.image as p_image, ribbon, sku_id, brand_id, track_inventory, has_variant, category_id, products.id as product_id, products.name as product_name, products.description as product_description, products.created, products.merchant_id as merchant_id from products inner join product_categories on products.category_id = product_categories.id inner join brand ON products.brand_id = brand.id WHERE (brand.name LIKE '%$text%' OR product_categories.name LIKE '%$text%' OR products.name LIKE '%$text%') AND products.visibility = '1' $filter LIMIT $startLimit,$data[recordsPerRequest]";
           $result      = $this->db_query($sql);
            
            if(count($result) > 0)
            {
                $counter_sql         = "SELECT  COUNT(products.id) as p_id from products inner join product_categories on products.category_id = product_categories.id inner join brand ON products.brand_id = brand.id WHERE (brand.name LIKE '%$text%' OR product_categories.name LIKE '%$text%' OR products.name LIKE '%$text%') AND products.visibility = '1' $filter ";
                $counter      = $this->db_query($counter_sql);
                $counter      = $counter[0]['p_id'];
                
                foreach($result as $row)
                {
                    $track_inventory = ($row['track_inventory'] == 1)?true:false;
                    $has_variant     = ($row['has_variant']    == 1)?true:false;
                    $categoryName    = $this->getitemlabel("product_categories","id",$row['category_id'],"name");
                    $merchant_id     = $row['merchant_id'];
                    $merchantName    = $this->getitemlabel("merchant_reg","merchant_id",$row['merchant_id'],"merchant_name");
                    $options[]       = array('productID'=>$row['product_id'], 'productName'=>$row['product_name'],'description'=>$row['product_description'],'brandID'=>$row['brand_id'],'category'=>array("id"=>$row['category_id'],"name"=>$categoryName), 'skuID'=>$row['sku_id'],'ribbon'=>$row['ribbon'], 'productImage'=>$row['p_image'], 'productPrice'=>$row['price'], 'discountPrice'=>$row['discount_price'], 'discountPercentage'=>$row['discounted_percentage'],'hasVariant'=>$has_variant, 'stockStatus'=>$row['stock_status'], 'created'=>$row['created'],'merchant'=>array('id'=>$merchant_id,'name'=>$merchantName),'inventory'=>array('quantity'=>$row['inventory'],'trackInventory'=>$track_inventory) );
                }
                return json_encode(array('responseCode'=>0,'responseMessage'=>'Successful','responseBody'=>array('products'=>$options,'totalRecords'=>$counter)));
            }
            else
            {
                return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
            } 
        }else
        {
            return json_encode(array('responseCode'=>17,'responseMessage'=>'character count is too short','responseBody'=>null));
        }
        
    }
    public function getFeaturedProducts($data)
    {
        $merchant_id = $this->merchantID;
        
        $startLimit  = ($data['pageNo'] - 1) * $data['recordsPerRequest'];
//        $filter      = (is_array($data['filter']))?$this->prepareProductFilter($data['filter']):"";
        $sql         = "SELECT * FROM products WHERE  visibility = '1' AND is_featured_product = '1'  LIMIT $startLimit,$data[recordsPerRequest]";
        $result      = $this->db_query($sql);
        
        
        
        $sql         = "SELECT id FROM products WHERE  visibility = '1' AND is_featured_product = '1'";
        $counter     = $this->db_query($sql,false);
        $options     = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $track_inventory = ($row['track_inventory'] == 1)?true:false;
                $categoryName    = $this->getitemlabel("product_categories","id",$row['category_id'],"name");
                $merchant_name    = $this->getitemlabel("merchant_reg","merchant_id",$row['merchant_id'],"merchant_name");
                $options[] = array('productID'=>$row['id'], 'merchantID'=>$row['merchant_id'],'merchantName'=>$merchant_name,'productName'=>$row['name'],'description'=>$row['description'],'brandID'=>$row['brand_id'],'category'=>array("id"=>$row['category_id'],"name"=>$categoryName), 'skuID'=>$row['sku_id'],'ribbon'=>$row['ribbon'], 'productImage'=>$row['image'], 'productPrice'=>$row['price'], 'discountPrice'=>$row['discount_price'], 'discountPercentage'=>$row['discounted_percentage'], 'stockStatus'=>$row['stock_status'], 'created'=>$row['created'],'inventory'=>array('quantity'=>$row['inventory'],'trackInventory'=>$track_inventory) );
            }
            shuffle($options);
            return json_encode(array('responseCode'=>0,'responseMessage'=>'Successful','responseBody'=>array('featuredProducts'=>$options,'totalRecords'=>$counter)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
        }
    }
    
    public function getSpecialOfferProducts()
    {
//        $filter      = (is_array($data['filter']))?$this->prepareProductFilter($data['filter']):"";
        $sql         = "SELECT * FROM products WHERE  visibility = '1' AND special_offer = '1' ";
        $result      = $this->db_query($sql);
        
        
 
        $options     = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $track_inventory = ($row['track_inventory'] == 1)?true:false;
                $categoryName    = $this->getitemlabel("product_categories","id",$row['category_id'],"name");
                $merchant_name    = $this->getitemlabel("merchant_reg","merchant_id",$row['merchant_id'],"merchant_name");
                $options[] = array('productID'=>$row['id'], 'merchantID'=>$row['merchant_id'],'merchantName'=>$merchant_name,'productName'=>$row['name'],'description'=>$row['description'],'brandID'=>$row['brand_id'],'category'=>array("id"=>$row['category_id'],"name"=>$categoryName), 'skuID'=>$row['sku_id'],'ribbon'=>$row['ribbon'], 'productImage'=>$row['image'], 'productPrice'=>$row['price'], 'discountPrice'=>$row['discount_price'], 'discountPercentage'=>$row['discounted_percentage'], 'stockStatus'=>$row['stock_status'], 'created'=>$row['created'] );
            }
            shuffle($options);
            return json_encode(array('responseCode'=>0,'responseMessage'=>'Successful','responseBody'=>array('specialOffer'=>$options)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
        }
    }
    
    public function getPickupStationOld($data)
    {
        $merchant_id = $this->merchantID;
        $state       = $data['state'];
        $lga         = $data['lga'];
         $sql         = "SELECT pickup_station,merchant_pickup_stores.address,merchant_pickup_stores.state,merchant_pickup_stores.pickup_instructions FROM shipping_regions INNER JOIN merchant_pickup_stores ON merchant_pickup_stores.id = shipping_regions.pickup_station WHERE FIND_IN_SET('$lga', lga) <> 0 AND shipping_regions.merchant_id = '$merchant_id' ";
        $result      = $this->db_query($sql);
        if(count($result) > 0)
        {
            $store_id        = $result[0]['pickup_station'];
            $pick_up_station = $this->getitemlabel('merchant_pickup_stores','id',$store_id,'title');
            json_encode(array('responseCode'=>0,'responseMessage'=>'Successful','responseBody'=>array('pickupStation'=>$pick_up_station)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
        }
    }
    public function getPickupStation($data)
    {
        $merchant_id = $this->merchantID;
        $state       = $data['state'];
        $lga         = $data['lga'];
        $sql         = "SELECT * FROM  merchant_pickup_stores  WHERE lga= '$lga' AND merchant_id = '$merchant_id' ";
        $result      = $this->db_query($sql);
        if(count($result) > 0)
        {
            $pick_up_station = array();
            foreach($result as $row)
            {
                $lga_name = $this->getitemlabel("lga","Lgaid",$lga,"Lga");
                $state_name = $this->getitemlabel("lga","Lgaid",$lga,"State");
                $pick_up_station[] = array("id"=>$row['id'],"name"=>$row['title'],"address"=>$row['address'],"pickupInstructions"=>$row['pickup_instructions'],"state"=>$state_name,"lga"=>$lga_name);
            }
            
            return json_encode(array('responseCode'=>0,'responseMessage'=>'Successful','responseBody'=>array('pickupStation'=>$pick_up_station)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
        }
    }
    public function getMerchants($data)
    {
        $startLimit = ($data['pageNo'] - 1) * $data['recordsPerRequest'];
        $cat_filter = $data['filter']['merchantCategory'];
        $filter  = isset($data['filter']['merchantCategory'])?" AND industry = '$cat_filter'":"";
        $sql    = "SELECT * FROM merchant_reg WHERE active_merchant = '1' $filter  LIMIT $startLimit,$data[recordsPerRequest]";
        $result = $this->db_query($sql);
        $sql    = "SELECT * FROM merchant_reg WHERE active_merchant = '1' ";
        $counter = $this->db_query($sql,false);
        $options = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $merchant_id = $row['merchant_id'];
                $category    = array('id'=>$row['industry'],'name'=>$this->getitemlabel('job_industry','id',$row['industry'],'name'));
                $prodSql = "SELECT id FROM products WHERE merchant_id = '$merchant_id'";
                $product_count = $this->db_query($prodSql,false);
                $options[] = array('merchantID'=>$row['merchant_id'],'merchantName'=>$row['merchant_name'],'productCount'=>$product_count,'merchantLogo'=>$row['merchant_logo'],'merchantCategory'=>$category);
            }
            return json_encode(array('responseCode'=>0,'responseMessage'=>'Successful','responseBody'=>array('merchants'=>$options,'totalRecords'=>$counter)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
        }
    }
    public function prepareProductFilter($data)
    {
        $filter = "";
        $in_brand = "";
        $in_category = "";
        $output = array();
        foreach($data as $key=>$value)
        {
            if(is_array($value) )
            {
                if($key == "brandID" && count($value) > 0)
                {
                    foreach($value as $v)
                        $in_brand .= "'".$v."',";
                    $in_brand = " AND brand_id IN (".substr($in_brand,0,-1).")";
                }
                if($key == "categoryID" && count($value) > 0)
                {
                    foreach($value as $v)
                        $in_category .= "'".$v."',";
                    $in_category = " AND category_id IN (".substr($in_category,0,-1).")";
                }
                if($key == "subcategoryID" && count($value) > 0)
                {
                    foreach($value as $v)
                        $in_subcategory .= "'".$v."',";
                    $in_category = " AND sub_category IN (".substr($in_subcategory,0,-1).")";
                }
//                if($key == "specialOffer" && count($value) > 0)
//                {
//                    foreach($value as $v)
//                        $in_special_offer .= "'".$v."',";
//                    $in_brand = "AND special_offer = (".substr($in_special_offer,0,-1).")";
//                }
                if($key == "price")
                {
                    $filter .= " AND discount_price BETWEEN $value[min] AND $value[max]";
                }
            }
            else
            {
                if($key == "specialOffer")
                {
                    $dd = ($value == true)?1:0;
                    $in_special_offer = " AND special_offer = '".$dd."'";
                }
            }
        }
         $filter = $in_brand.$in_category.$in_special_offer.$filter;
        return $filter;
    }
    public function getProducts($data)
    {
        $merchant_id = $this->merchantID;
//        var_dump($data);
        $startLimit  = ($data['pageNo'] - 1) * $data['recordsPerRequest'];
        $merchant_id = $this->merchantID;
        $filter = (isset($data['filter']))?$this->prepareProductFilter($data['filter']):"";
        $sql    = "SELECT * FROM products WHERE visibility = '1' $filter  LIMIT $startLimit,$data[recordsPerRequest]";
        $result = $this->db_query($sql);
        $sql    = "SELECT id FROM products WHERE  AND visibility = '1' $filter";
        $counter = $this->db_query($sql,false);
        $options = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $track_inventory = ($row['track_inventory'] == 1)?true:false;
                $has_variant     = ($row['has_variant']    == 1)?true:false;
                $categoryName    = $this->getitemlabel("product_categories","id",$row['category_id'],"name");
                $subcategoryName = $this->getitemlabel("product_subcategory","id",$row['sub_category'],"name");
                $merchantName    = $this->getitemlabel("merchant_reg","merchant_id",$row['merchant_id'],"merchant_name");
                $options[]       = array('productID'=>$row['id'], 'productName'=>$row['name'],'description'=>$row['description'],'brandID'=>$row['brand_id'],'category'=>array("id"=>$row['category_id'],"name"=>$categoryName),'subcategory'=>array("id"=>$row['sub_category'],"name"=>$subcategoryName), 'skuID'=>$row['sku_id'],'ribbon'=>$row['ribbon'], 'productImage'=>$row['image'], 'productPrice'=>$row['price'], 'discountPrice'=>$row['discount_price'], 'discountPercentage'=>$row['discounted_percentage'],'hasVariant'=>$has_variant, 'stockStatus'=>$row['stock_status'], 'created'=>$row['created'],'inventory'=>array('quantity'=>$row['inventory'],'trackInventory'=>$track_inventory),'merchant'=>array('id'=>$row['merchant_id'],'name'=>$merchantName) );
            }
            return json_encode(array('responseCode'=>0,'responseMessage'=>'Successful','responseBody'=>array('products'=>$options,'totalRecords'=>$counter)));
        }
        else
        {
            return json_encode(array('responseCode'=>77,'responseMessage'=>'No record found','responseBody'=>null));
        }
    }
    public function getProductDetails($data)
    {
        $merchant_id    = $this->merchantID;
        $id             = $data['id'];
        $sql            = "SELECT id,has_variant,price,name,description,discount_price,image,weight,stock_status,category_id,sub_category,merchant_id FROM products  WHERE id = '$id'  LIMIT 1 ";
        $result         = $this->db_query($sql);
        if(count($result) > 0)
        {

            $productDetails = array();
            $variantDetails = null;
            if($result[0]['has_variant'] == "1")
            {
                $sql2     = "SELECT * FROM product_variant WHERE product_id = '$id' AND visibility = '1' ";
                $result_2 = $this->db_query($sql2);
                if(count($result_2) > 0)
                {
                   foreach($result_2 as $row)
                    {
                        $variantDetails[] = array("id"=>$row['id'],"name"=>$row['name'],"price"=>$row['price'],"stockStatus"=>$row['stock_status'],"weight"=>$row['weight']);
                    }
                }
            }
            $image_sql = "SELECT location FROM product_images WHERE product_id = '$id'";
            $image_result = $this->db_query($image_sql);
            $product_images = null;
            if(count($image_result) > 0)
            {
                $product_images = array();
                foreach($image_result as $row)
                {
                    $product_images[] = $row['location'];
                }
            }

            $additional_sql = "SELECT info_title,description FROM product_additional_information  WHERE product_id = '$id'";
            $additional_result = $this->db_query($additional_sql);
            $product_additional_info = null;
            if(count($additional_result) > 0)
            {
                $product_additional_info = array();
                foreach($additional_result as $row)
                {
                    $product_additional_info[] = array("title"=>$row['info_title'],"description"=>$row['description']);
                }
            }
            $has_variant    = ($result[0]['has_variant'] == "1")?true:false;
            $category_name = $this->getitemlabel('product_categories','id',$result[0]['category_id'],'name');
            $subcategory_name = $this->getitemlabel('product_subcategory','id',$result[0]['sub_category'],'name');
            $merchant_name = $this->getitemlabel('merchant_reg','merchant_id',$result[0]['merchant_id'],'merchant_name');
            
            $productDetails = array("id"=>$result[0]['id'], "name"=>$result[0]['name'],"merchant"=>array('id'=>$result[0]['merchant_id'],'name'=>$merchant_name), "price"=>$result[0]['price'], "stockStatus"=>$result[0]['stock_status'],"discountPrice"=>$result[0]['discount_price'], "description"=>$result[0]["description"], "hasVariant"=>$has_variant, "productVariant"=>$variantDetails,"productMainImage"=>$result[0]['image'], "productImages"=>$product_images, "additionalInfo"=>$product_additional_info,"category"=>array('id'=>$result[0]['category_id'],'name'=>$category_name,'subcategory'=>array('id'=>$result[0]['sub_category'],'name'=>$subcategory_name)));
           return  json_encode(array('responseCode'=>0,'responseMessage'=>'Successful','responseBody'=>array('productDetails'=>$productDetails)));
        }else
        {
            return  json_encode(array('responseCode'=>78,'responseMessage'=>'Product not found'));
        }
    }
    public function customerLogin($data)
    {
        
//        return var_dump($this->verifyToken());
//        $aesObj = new AESAlgo();
//        $key   = "123456";
//        $data  = array("username"=>$aesObj->encryptString("customer@mail.com", $key),"password"=>$aesObj->encryptString("abc123456", $key));
//        
//        
//        $username = $aesObj->decryptString($data['username'], $key);
//        $password = $aesObj->decryptString($data['password'], $key);
        $validate = $this->validate($data,array('email'=>'required','password'=>'required'));
        if($validate['error'])
        {
            return json_encode(array('responseCode'=>13,'responseMessage'=>$validate['messages'][0]));
        }
        $username = $data['email'];
        $sql      = "SELECT * FROM userdata_customer WHERE username = '$username' LIMIT 1";
		$result   = $this->db_query($sql);
		$count    = count($result); 
		if($count > 0)
		{
            
//            $datetime1 = new DateTime();
//            $datetime2 = new DateTime('2020-01-03 17:13:00');
//            $interval = $datetime1->diff($datetime2);
//            $elapsed = $interval->format('%y years %m months %a days %h hours %i minutes %s seconds');
//            echo $elapsed;
//            if($result[0]['is_email_verified'] == "1")
//            {
                if($result[0]['pin_missed'] < 5)
                {
                    $encrypted_password = $result[0]['password'];
                    $is_locked     = $result[0]['user_locked'];
                    $is_disabled     = $result[0]['user_disabled'];
                    // $verify_pass   = password_verify($password,$hash_password);

                    $algo = new AESAlgo();
                    $decryptedPassword = $algo->decryptString($encrypted_password,$data['email']);
                    if($decryptedPassword == $data['password'])
                    {
                        if($is_disabled != 1)
                        {
                            if($is_locked != 1)
                            {
                                //update pin missed and last_login
                                $this->resetpinmissed($username);

                                $firstname = $result[0]['first_name'];
                                $lastname = $result[0]['last_name'];
                                $username = $result[0]['username'];
                                $payload  = array('firstname'=>$firstname,'username'=>$username,'lastname'=>$lastname);
                                $token = $this->generateToken($payload,"new");
                                return json_encode(array("responseCode"=>0,"responseMessage"=>"Login Successful","responseBody"=>array("token"=>$token,'customerRecord'=>$this->setCustomerRecord($payload))));
                            }
                            else
                            {
                                return json_encode(array("responseCode"=>60,"responseMessage"=>"Your account has been locked, kindly contact the administrator."));
                            }
                        }
                        else
                        {
                            return json_encode(array("responseCode"=>610,"responseMessage"=>"Your user privilege has been revoked. Kindly contact the administrator"));
                        }
                    }
                    else
                    {
                        $this->updatepinmissed($username);

                        $remaining = (($result[0]['pin_missed']+1) <= 5)?(5-($result[0]['pin_missed']+1)):0;
                        return json_encode(array("responseCode"=>90,"responseMessage"=>"Invalid username or password, ".$remaining." attempt remaining"));
                    }
                }
                elseif($result[0]['pin_missed'] == 5)
                {
                    $this->updateuserlock($username,'1');
                    return json_encode(array("responseCode"=>64,"responseMessage"=>"Your account has been locked, kindly contact the administrator."));
                }
                else
                {
                     return json_encode(array("responseCode"=>62,"responseMessage"=>"Your account has been locked, kindly contact the administrator."));
                } 
//            }
//            else
//            {
//                return json_encode(array("responseCode"=>20,"responseMessage"=>"Your account has not been verified!"));
//            }
            
        }else
        {
            return json_encode(array("responseCode"=>20,"responseMessage"=>"Invalid username or password"));
        }
    }
    public function addCustomerAddress($data,$c_id)
    {
        $customer_id  = $c_id;
        $phone_number = $data['phoneNumber'];
        $address      = $data['addressNo'];
        $state        = $data['state'];
        $lga          = $data['lga'];
        $first_name   = $data['firstName'];
        $last_name        = $data['lastName'];
        $isPrimaryAddress = ($data['isPrimaryAddress'] === true)?"1":"0";
        $validate         = $this->validate($data,array('addressNo'=>'required','firstName'=>'required','lastName'=>'required','phoneNumber'=>'required','state'=>'required','lga'=>'required','isPrimaryAddress'=>'boolean'));
        if($validate['error'])
        {
            return json_encode(array('responseCode'=>13,'responseMessage'=>$validate['messages'][0]));
        }
        if($isPrimaryAddress == "1")
        {
            $sql = "UPDATE customer_address SET is_primary_address = '0' WHERE customer_id = '$customer_id'";
            $this->db_query($sql,false);
        }
        
        
        $sql   = "INSERT INTO customer_address (address,state,lga,f_name,l_name,created,customer_id,phone_number,is_primary_address) VALUES('$address','$state','$lga','$first_name','$last_name',NOW(),'$customer_id','$phone_number','$isPrimaryAddress') ";
        $count = $this->db_query($sql,false);
        if($count > 0)
        {
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Address added successfuly"));
        }
        else
        {
            return json_encode(array("responseCode"=>20,"responseMessage"=>"Failed to save address"));
        }
    }
    
    public function getStates()
    {
//        $state = $data['state'];
        $sql = "SELECT DISTINCT(State) as State,state_code FROM lga";
        $result       = $this->db_query($sql);
        $states   = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $states[] = array("name"=>$row['State'],"id"=>$row['state_code']);
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"success","responseBody"=>array("states"=>$states)));
        }else
        {
            return json_encode(array("responseCode"=>201,"responseMessage"=>"Failed to fetch State list","responseBody"=>null));
        }
    }
    public function getLga($data)
    {
        $state_id = $data['stateID'];
        $sql = "SELECT * FROM lga WHERE state_code = '$state_id'";
        $result       = $this->db_query($sql);
        $lga   = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $lga[] = array("name"=>$row['Lga'],"id"=>$row['Lgaid']);
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"success","responseBody"=>array("states"=>$lga)));
        }else
        {
            return json_encode(array("responseCode"=>201,"responseMessage"=>"Failed to fetch lga list","responseBody"=>null));
        }
    }
    public function viewCustomerAddress($data,$c_id)
    {
        $customer_id  = $c_id;
        $filter       = ($data['addressID'] == "*")?"":" AND id = '$data[addressID]'";
        $sql          = "SELECT * FROM customer_address WHERE customer_id = '$customer_id' $filter";
        $result       = $this->db_query($sql);
        $info         = array();
        if(count($result) > 0)
        {
            foreach($result as $row)
            {
                $is_default = ($row['is_primary_address'] == 1)?true:false;
                $info[] = array('id'=>$row['id'],'addressNo'=>$row['address'],'state'=>array("id"=>$row['state'],"name"=>$this->getitemlabel("lga","state_code",$row['state'],"State")),'lga'=>array("id"=>$row['lga'],"name"=>$this->getitemlabel("lga","Lgaid",$row['lga'],"Lga")),'firstName'=>$row['f_name'],'lastName'=>$row['l_name'],'phoneNumber'=>$row['phone_number'],'customerID'=>$row['customer_id'],'isPrimaryAddress'=>$is_default,'created'=>$row['created']);
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Address fetched successfuly","responseBody"=>array("address"=>$info)));
        }else
        {
            return json_encode(array("responseCode"=>201,"responseMessage"=>"Failed to fetch address","responseBody"=>null));
        }
    }
    public function customerLogout($data)
    {
        // generate a new token; set the exp time to a past time and send to the client to update
        $status = $this->verifyToken();
        if($status["responseCode"] == 0)
        {
            $customerRecord = $this->setCustomerRecord($status['responseBody']['customerRecord']);
            $expiredToken    = $this->generateToken($customerRecord,"destroy");
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Logout Successful","responseBody"=>array("token"=>$expiredToken))); // tokens will be sent back in the header
        }else
        {
            return json_encode(array("responseCode"=>78,"responseMessage"=>"Logout Failed: ".$status['responseMessage'],"responseBody"=>null));
        }
    }
    public function customerRegistration($data)
    {
        // collect the data and validate, also do mysql escape string,
        // check if user already exist
        // save record to database
        // create wallet for user
        // send verification email to user,
//        var_dump($data);
        $validate = $this->validate($data,array('email'=>'required|email|unique:userdata_customer.username','password'=>'required|min:8','firstName'=>'required|min:2','lastName'=>'required|min:2','phone'=>'required|int|min:9','gender'=>'required'));
        if($validate['error'])
        {
            return json_encode(array('responseCode'=>13,'responseMessage'=>$validate['messages'][0]));
        }
        $algo = new AESAlgo();
        $encryptedPassword = $algo->encryptString($data['password'],$data['email']);
        
        $sql = "INSERT INTO userdata_customer (first_name,last_name,username,phone,created,is_active,password,email,passchg_logon,pass_expire,user_locked,pin_missed,sex,email_verify_link,email_verify_link_expire) VALUES('$data[firstName]','$data[lastName]','$data[email]','$data[phone]',NOW(),'0','$encryptedPassword','$data[email]','0','3020','0','0','$data[gender]','','')";
        $result = $this->db_query($sql,false);
        // Send a welcome email message after successful registration
        if($result > 0)
        {
            
            $notificationObj = new Notification();
            $templateObj     = new EmailTemplate(); 
            $firstname       = $data['firstName'];
            $lastname        = $data['lastName'];
            $email        = $data['email'];
            $message         = $templateObj->emailVerificationAPI(array('title'=>'Welcome to '.$this->applicationName,'body'=>'<b>Hello '.$firstname.' '.$lastname.'!</b><p>Thank you for choosing '.$this->applicationName.', .</p><div>
            </div><br/><br/><p>Best Regards,</p><b>'.$this->applicationName.' Team!</b>'));
            $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>'WELCOME TO '.$this->applicationName,'to'=>$email,'message'=>$message));
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Registration successful."));
        }
        else
        {
            return json_encode(array("responseCode"=>73,"responseMessage"=>"Registration failed. Something went wrong"));
        }
            

        
    }
    public function sendVerificationCode($data)
    {
        $email  = $data['username'];
        $sql    = "SELECT username,first_name,last_name FROM userdata_customer WHERE username = '$email' AND is_email_verified = '0' LIMIT 1";
        $result = $this->db_query($sql);
        if(count($result) < 1)
        {
            return json_encode(array("responseCode"=>926,"responseMessage"=>"This account has already been verified or does not exist."));
        }
        
        $token           = $this->generateEmailVerificationToken();
        $firstname       = $result[0]['first_name']; 
        $lastname        = $result[0]['last_name']; 
        $email           = $result[0]['username'];
        
        $sql             = "UPDATE userdata_customer SET email_verify_link = '$token', email_verify_link_expire = DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE email = '$email' LIMIT 1";
        $count           = $this->db_query($sql,false);
        
        if($count > 0)
        {
            $notificationObj = new Notification();
            $templateObj     = new EmailTemplate(); 
            $message         = $templateObj->emailVerificationAPI(array('title'=>'Email Verification','body'=>'<b>Hello '.$firstname.' '.$lastname.'!</b><p>Before you can start buying on '.$this->applicationName.', you need to confirm your email address.</p><div>Kindly use this code below to verify your account.
            </div><h2 align="center"><b>'.$token.'</b></h2><br/><br/><p>Best Regards,</p><b>'.$this->applicationName.'!</b>'));
            $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>$this->applicationName.' EMAIL VERIFICATION','to'=>$email,'message'=>$message));
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Verification token has been sent to your registered email."));
        }else
        {
            return json_encode(array("responseCode"=>713,"responseMessage"=>"Failed to create your verification token."));
        }
        
    }
    public function checkAccountVerificationStatus($data)
    {
        $email = $data['email'];
        $sql    = "SELECT username,is_email_verified FROM userdata_customer WHERE email = '$email'  LIMIT 1 ";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            $verification_status = $result[0]['is_email_verified'];
            if($verification_status == "1")
            {
                return json_encode(array("responseCode"=>0,"responseMessage"=>"Success! Account has been verified"));
            }
            else
            {
                return json_encode(array("responseCode"=>"z500","responseMessage"=>"Account has not been verified"));
            }
        }else
        {
            return json_encode(array("responseCode"=>783,"responseMessage"=>"Username does not exist."));
        }
        
    }
    public function getBanner()
    {
//        $sql    = "SELECT * FROM banner_table WHERE expires_on > CURDATE()";
        $sql    = "SELECT * FROM banner_table ";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            $banners = array();
            $carousel = array();
            foreach($result as $row)
            {
                if($row['is_carousel'] == "0")
                {
                    $banners[] = array("productID"=>$row['product_id'],"categoryID"=>$row['category_id'],"merchantID"=>$row['merchant_id'],"description"=>$row['description'],"image"=>$row['image'],"buttonTitle"=>$row['button_name'],"position"=>$row['position']);
                }else
                {
                    $carousel[] = array("productID"=>$row['product_id'],"categoryID"=>$row['category_id'],"merchantID"=>$row['merchant_id'],"description"=>$row['description'],"image"=>$row['image'],"buttonTitle"=>$row['button_name'],"position"=>$row['position']);
                }
                
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"OK","responseBody"=>array("banners"=>$banners,"carousel"=>$carousel)));
        }
        else
        {
            return json_encode(array("responseCode"=>783,"responseMessage"=>"No banners yet"));
        }
    }
    public function getCouponValue($data)
    {
        $email       = $data['username'];
        $coupon_code = $data['couponCode'];
        $sql         = "SELECT * FROM coupon WHERE (customer_link = '$email' OR customer_link = '*') AND is_active = '1' AND used_status = '0' AND expire_date >= CURDATE() AND CURDATE() >= start_date AND id ='$coupon_code' LIMIT 1  ";
        $result      = $this->db_query($sql);
        if(count($result) > 0)
        {
            $coupons = array();
            foreach($result as $row)
            {
                $merchant_name = $this->getitemlabel("merchant_reg","merchant_id",$row['merchant_id'],"merchant_name");
                $forUseBy = ($row['customer_link'] == "*")?"All Customers":$row['customer_link'];
                $coupons[] = array("code"=>$row['id'],"name"=>$row['name'],"value"=>$row['value'],"expireDate"=>$row['expire_date'],"availableTo"=>$forUseBy,"merchant"=>array("id"=>$row['merchant_id'],"name"=>$merchant_name));
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Record Found","responseBody"=>array("coupons"=>$coupons)));
        }
        else
        {
            return json_encode(array("responseCode"=>99,"responseMessage"=>"Coupon code is invalid","responseBody"=>null));
        }
    }
    public function bestSellers()
    {
        $sql = "SELECT COUNT(product_id) as top_product,product_id,product_name FROM orderdetails INNER JOIN products ON products.id = orderdetails.product_id WHERE payment = '1' AND visibility = '1' GROUP BY product_id ORDER BY top_product LIMIT 5 ";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            $product = array();
            foreach($result as $row)
            {
                $obj = json_decode($this->getProductDetails(array('id'=>$row['product_id'])),TRUE);
                if($obj['responseCode'] == 0)
                {
                    $product[] = $obj['responseBody']['productDetails'];
                }
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Record Found","responseBody"=>array("products"=>$product)));
        }else
        {
            return json_encode(array("responseCode"=>392,"responseMessage"=>"Record Not Found","responseBody"=>array("products"=>$product)));
        }
        
    }
    public function getTopMerchants()
    {
        $sql    = "SELECT count(destination_acct) top_merchant, merchant_id FROM transaction_table WHERE trans_type ='ORDER'  GROUP BY destination_acct ORDER  BY top_merchant desc";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            $merchants = array();
            foreach($result as $row)
            {
                $merchants[] = array("merchantID"=>$row['merchant_id'],"description"=>$row['description'],"boldDescription"=>$row['bold_description'],"image"=>$row['image'],"buttonTitle"=>$row['button_name'],"position"=>$row['position']);
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"OK","responseBody"=>array("merchants"=>$merchants)));
        }
        else
        {
            return json_encode(array("responseCode"=>783,"responseMessage"=>"No top merchants yet"));
        }
    }
    public function resetPassword($data)
    {
        $username = $data['username'];
        $sql      = "SELECT username,first_name,last_name,is_email_verified FROM userdata_customer WHERE username = '$username' LIMIT 1";
        $result   = $this->db_query($sql);
        if(count($result) > 0)
        {
//            if($result[0]['is_email_verified'] == "1")
//            {
                $link = $this->generateLinkToken();
                $sql = "UPDATE userdata_customer SET forgot_pwd_link = '$link', forgot_pwd_link_expire = DATE_ADD(NOW(), INTERVAL 10 MINUTE) WHERE username = '$username' LIMIT 1";
                $this->db_query($sql,false);
                $ip = $_SERVER['REMOTE_ADDR'];
                $firstname = $result[0]['first_name'];
                $lastname = $result[0]['last_name'];
                $notificationObj = new Notification();
                $templateObj     = new EmailTemplate(); 
                $message         = $templateObj->emailVerificationAPI(array('title'=>'Forgot Password','body'=>'<b>Hello '.$firstname.' '.$lastname.'!</b><p>You recently requested to reset your password for '.$username.'. Use the button below to reset it. <b>This password reset is only valid for the next 12 hours.</b></p><div><a href="'.$this->frontendBaseUrl.'reset_password.php?ga='.$link.'" style="color: #ffffff; background: #1b9f1e; font-weight: 900; font-style: normal; padding: 12px 28px; font-size: 12pt; border-radius: 5px; height: 20px; line-height: 1.25; position: relative; bottom: 2px; margin-left: 0px; margin-right: 0px; text-decoration: none; word-spacing: 1px; display: block; text-align: center">Reset your password</a></div><br/><br/><p>For security reasons this request was received from '.$ip.' IP address. </p><p>If you did not request a password reset, please ignore this email.</p><br/><br/><p>Best Regards,</p><b>'.$this->applicationName.' Team!</b>'));

                $notificationObj->sendNotification(array('method'=>'email'))->sendHtml(array('subject'=>$this->applicationName.' FORGOT PASSWORD','to'=>$username,'message'=>$message));

                return json_encode(array("responseCode"=>0,"responseMessage"=>"Please follow the link sent to your email to complete the password change."));
//            }
//            else
//            {
//                return json_encode(array("responseCode"=>78,"responseMessage"=>"Email has not been verified!"));
//            }
        }
        else
        {
            return json_encode(array("responseCode"=>77,"responseMessage"=>"This account does not exist in our system.")); 
        }
    }
    public function verifyPasswordLink($data)
    {
        $link = $data['link'];
        $sql = "SELECT TIMESTAMPDIFF(HOUR,NOW(),forgot_pwd_link_expire) AS t_diff_hr,TIMESTAMPDIFF(MINUTE,NOW(),forgot_pwd_link_expire) AS t_diff_min,email,is_email_verified FROM userdata_customer WHERE forgot_pwd_link = '$link' LIMIT 1";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            if($result[0]['is_email_verified'] == "1")
            {
                if($result[0]['t_diff_min'] > 0 )
                {
                    $email = $result[0]['email'];
                    return json_encode(array("responseCode"=>0,"responseMessage"=>"This link is still valid.","responseBody"=>array("username"=>$email))); 
                }
                else
                {
                    return json_encode(array("responseCode"=>77,"responseMessage"=>"This link has expired.")); 
                }
            }else
            {
                return json_encode(array("responseCode"=>78,"responseMessage"=>"Email has not been verified!"));
            }
            
        }
        else
        {
            return json_encode(array("responseCode"=>77,"responseMessage"=>"This link has expired or is invalid.")); 
        }
    }
    public function doResetPassword($data)
    {
        $password   = $data['password'];
        $c_password = $data['confirmPassword'];
        $link       = $data['link'];
        
        $sql        = "SELECT username FROM userdata_customer WHERE forgot_pwd_link = '$link' LIMIT 1";
        $result     = $this->db_query($sql);
        if(count($result) > 0)
        {
            $email             = $result[0]['username'];
            $algo              = new AESAlgo();
            $encryptedPassword = $algo->encryptString($password,$email);
            $sql               = "UPDATE userdata_customer SET password = '$encryptedPassword', passchg_logon = '0', user_locked = '0' WHERE forgot_pwd_link = '$link'  LIMIT 1";
            $count2            = $this->db_query($sql,false);
            if($count2 > 0)
            {
                $sql               = "UPDATE userdata_customer SET forgot_pwd_link = '' WHERE forgot_pwd_link = '$link'  LIMIT 1";
                $count2            = $this->db_query($sql,false);
                return json_encode(array("responseCode"=>0,"responseMessage"=>"Password change was successful")); 
            }else
            {
                 return json_encode(array("responseCode"=>77,"responseMessage"=>"This link has expired or is invalid."));
            }
        }else
        {
             return json_encode(array("responseCode"=>96,"responseMessage"=>"This link is invalid."));
        }
        
    }
    
    public function verifyEmail($data)
    {
        // check if link exist,
        // check if link has been verified
        // check if link has expired
        $link = $data['link'];
        $sql  = "SELECT TIMESTAMPDIFF(HOUR,NOW(),email_verify_link_expire) AS t_diff_hr,TIMESTAMPDIFF(MINUTE,NOW(),email_verify_link_expire) AS t_diff_min,email, is_email_verified FROM userdata_customer WHERE email_verify_link = '$link' LIMIT 1";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            if($result[0]['is_email_verified'] == 0)
            {
                if($result[0]['t_diff_min'] > 0 )
                {
                    $email = $result[0]['email'];
                    $sql = "UPDATE userdata_customer SET is_email_verified = '1', email_verified_date = NOW() WHERE username = '$email' LIMIT 1";
                    $rr = $this->db_query($sql,false);
                    return json_encode(array("responseCode"=>0,"responseMessage"=>"This token is still valid.","responseBody"=>array("username"=>$email))); 
                }
                else
                {
                    return json_encode(array("responseCode"=>77,"responseMessage"=>"This token has expired.")); 
                }
            }
            else
            {
                return json_encode(array("responseCode"=>77,"responseMessage"=>"This email has already been verified!")); 
            }
        }
        else
        {
            return json_encode(array("responseCode"=>77,"responseMessage"=>"This token has expired or is invalid.")); 
        }
    }
    public function customerDetails($data,$c_id)
    {
        $username  = $c_id;
        $sql      = "SELECT * FROM userdata_customer WHERE username = '$username' LIMIT 1";
        $result   = $this->db_query($sql);
        if(count($result) > 0)
        {
            if($result[0]['user_locked'] != 1)
            {
                $locations = $this->getitemlabelArr("lga",array("Lgaid"),array($result[0]["state_lga"]),array("State","Lga"));
                $state     = $locations['State'];
                $lga       = $locations['Lga'];
                $addresses = json_decode($this->viewCustomerAddress(array('addressID'=>'*'),$c_id),TRUE);
                $customer_details = array("firstName"=>$result[0]["first_name"],"lastName"=>$result[0]["last_name"],"phone"=>$result[0]["phone"],"gender"=>$result[0]["sex"],"email"=>$result[0]["email"],"address"=>$addresses['responseBody']['address']);
                
                return json_encode(array("responseCode"=>0,"responseMessage"=>"Record Found","responseBody"=>array("customerDetails"=>$customer_details)));
            }
            else
            {
                return json_encode(array("responseCode"=>51,"responseMessage"=>"Your profile has been locked. Kindly contact the admin.","responseBody"=>null));
            }
        }
        else
        {
            return json_encode(array("responseCode"=>99,"responseMessage"=>"Your session has expired.","responseBody"=>null));
        }
    }
    public function updateCustomerDetails($data,$c_id)
    {
        $username  = $c_id;
        $validate = $this->validate($data,array('firstName'=>'required|min:2','lastName'=>'required|min:2','phone'=>'required|int|min:9','gender'=>'required'));
        if($validate['error'])
        {
            return json_encode(array('responseCode'=>13,'responseMessage'=>$validate['messages'][0]));
        }
        $sql = "UPDATE userdata_customer SET first_name = '$data[firstName]', last_name = '$data[lastName]', phone = '$data[phone]', sex = '$data[gender]' WHERE username = '$username' LIMIT 1";
        $result = $this->db_query($sql,false);
        if($result > 0)
            {
                return json_encode(array("responseCode"=>0,"responseMessage"=>"Profile updated!"));
            }
            else
            {
                return json_encode(array("responseCode"=>99,"responseMessage"=>"Could not update your profile, try again later."));
            }
    }
    public function deleteCustomerAddress($data,$c_id)
    {
        $username = $c_id;
        $address_id = $data['addressID'];
        if($address_id != "")
        {
            $sql = "DELETE FROM customer_address WHERE id = '$address_id' AND customer_id = '$username' LIMIT 1 ";
            $result = $this->db_query($sql,false);
            if($result > 0)
            {
                return json_encode(array("responseCode"=>0,"responseMessage"=>"Address deleted!"));
            }
            else
            {
                return json_encode(array("responseCode"=>99,"responseMessage"=>"Could not delete the address, try again later."));
            }
        }
        else
        {
            return json_encode(array("responseCode"=>99,"responseMessage"=>"AddressID cannot be empty"));
        }
        
    }
    public function setPrimaryAddress($data)
    {
        $username = $data['username'];
        $address_id  = $data['addressID'];
        
        $sql = "UPDATE customer_address SET is_primary_address = '0' WHERE customer_id = '$username'";
        $this->db_query($sql,false);
        
        
        $sql = "UPDATE customer_address SET  is_primary_address = '1' WHERE id = '$address_id' AND customer_id = '$username' LIMIT 1 ";
        $result = $this->db_query($sql,false);
        if($result > 0)
        {
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Address updated!"));
        }
        else
        {
            return json_encode(array("responseCode"=>99,"responseMessage"=>"Could not update the address, try again later."));
        }
    }
    public function editCustomerAddress($data,$c_id)
    {
        $username = $c_id;
        $address_id = $data['addressID'];
        
        $phone_number = $data['phoneNumber'];
        $address      = $data['addressNo'];
        $state        = $data['state'];
        $lga          = $data['lga'];
        $first_name   = $data['firstName'];
        $last_name        = $data['lastName'];
        $isPrimaryAddress = ($data['isPrimaryAddress'] === true)?"1":"0";
        $validate         = $this->validate($data,array('addressNo'=>'required','firstName'=>'required','lastName'=>'required','phoneNumber'=>'required','state'=>'required','lga'=>'required','isPrimaryAddress'=>'boolean','addressID'=>'required'));
        if($validate['error'])
        {
            return json_encode(array('responseCode'=>13,'responseMessage'=>$validate['messages'][0]));
        }
        if($isPrimaryAddress == "1")
        {
            $sql = "UPDATE customer_address SET is_primary_address = '0' WHERE customer_id = '$username'";
            $this->db_query($sql,false);
        }
        
        
        if($address_id != "")
        {
            $sql = "SELECT address FROM customer_address WHERE id = '$address_id' LIMIT 1";
            $counting = $this->db_query($sql,false);
            if($counting > 0)
            {
                $sql = "UPDATE customer_address SET address= '$address',is_primary_address = '$isPrimaryAddress', state = '$state', lga = '$lga',f_name ='$first_name', l_name='$last_name',phone_number = '$phone_number' WHERE id = '$address_id' AND customer_id = '$username' LIMIT 1 ";
                $result = $this->db_query($sql,false);
                if($result > 0)
                {
                    return json_encode(array("responseCode"=>0,"responseMessage"=>"Address updated!"));
                }
                else
                {
                    return json_encode(array("responseCode"=>99,"responseMessage"=>"Could not update the address, try again later."));
                }
            }else
            {
                return json_encode(array("responseCode"=>99,"responseMessage"=>"Address ID is invalid"));
            }
        }
        else
        {
            return json_encode(array("responseCode"=>99,"responseMessage"=>"AddressID cannot be empty"));
        }
    }
    public function customerCoupons($c_id)
    {
        $username = $c_id;
        $sql = "SELECT * FROM coupon WHERE (customer_link = '$username' OR customer_link = '*') AND is_active = '1' AND used_status = '0' AND expire_date >= CURDATE() AND CURDATE() >= start_date  ";
        $result = $this->db_query($sql);
        if(count($result) > 0)
        {
            $coupons = array();
            foreach($result as $row)
            {
                $merchant_name = $this->getitemlabel("merchant_reg","merchant_id",$row['merchant_id'],"merchant_name");
                $forUseBy = ($row['customer_link'] == "*")?"All Customers":$row['customer_link'];
                $coupons[] = array("code"=>$row['id'],"name"=>$row['name'],"value"=>$row['value'],"expireDate"=>$row['expire_date'],"availableTo"=>$forUseBy,"merchant"=>array("id"=>$row['merchant_id'],"name"=>$merchant_name));
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Record Found","responseBody"=>array("coupons"=>$coupons)));
        }
        else
        {
            return json_encode(array("responseCode"=>99,"responseMessage"=>"No coupon available","responseBody"=>null));
        }
    }
    public function customerViewOrders($data)
    {
        $username    = $data['username'];
        $startLimit  = ($data['pageNo'] - 1) * $data['recordsPerRequest'];
        $filter      = (isset($data['orderID']))?" AND orderid = '$data[orderID]'":"";
        
        $sql         = "SELECT COUNT(customerid) no_of_records FROM orderdetails WHERE customerid = '$username'  $filter ";
        $count       = $this->db_query($sql);
        $count       = $count[0]['no_of_records'];
        
        
        $sql         = "SELECT * FROM orderdetails WHERE customerid = '$username'  $filter LIMIT $startLimit,$data[recordsPerRequest]";
        $result      = $this->db_query($sql);
        if(count($result) > 0)
        {
            $orders = array();
            foreach($result as $row)
            {
                $has_variant = ($row['has_variant'] == "1")?true:false;
                $status = array("0"=>"PENDING CONFIRMATION","1"=>"CONFIRMED","2"=>"DECLINED","3"=>"CANCELED","4"=>"CLOSED","5"=>"INITIALIZED");
                $image = $this->getitemlabel('products','id',$row['product_id'],'image');
                $delivery_method = $row['delivery_method'];
                $customer_address = $row['customer_address'];
                $customer_lga = $row['customer_lga'];
                $customer_state = $row['customer_state'];
                $customer_phone_number = $row['customer_phone_number'];
                $order[] = array("orderID"=>$row['orderid'],"product"=>array('name'=>$row['product_name'],'id'=>$row['product_id'],'price'=>$row['total_price'],"image"=>$image),"hasVariant"=>$has_variant,"quantity"=>$row['quantity'],"orderStatus"=>$status[$row[order_status]],"variant"=>array("name"=>$row['variant_name'],"price"=>$row['variant_price']));
            }
            $more = array();
            if(isset($data['orderID']))
            {
                $more['deliveryMethod']  = $delivery_method;
                $more['deliveryAddress'] = $customer_address;
                $more['deliveryState'] = $customer_state;
                $more['deliveryLga'] = $customer_lga;
                $more['deliveryPhoneNumber'] = $customer_phone_number;
                $sql12 = "SELECT total_shipping_price FROM transaction_table WHERE customer_id = '$username' AND order_id = '$row[orderid]' LIMIT 1";
                $res12 = $this->db_query($sql12);
                $more['shippingFee']  = $res12[0]['total_shipping_price'];
            }
            return json_encode(array("responseCode"=>0,"responseMessage"=>"Record found","responseBody"=>array("orders"=>$order,"totalRecord"=>$count,"more"=>$more)));
        }
        else
        {
            return json_encode(array("responseCode"=>445,"responseMessage"=>"No record found","responseBody"=>null));
        }
    }
    public function cancelOrder($data)
    {
        $order_id = $data['orderID'];
        $username = $data['username'];
        $sql      = "SELECT * FROM orderdetails WHERE id = '$order_id' AND customer_id = '$username' ";
        $result   = $this->db_query($sql);
        foreach($result as $row)
        {
            if($row['order_status'] != "1")
            {
                return json_encode(array("responseCode"=>445,"responseMessage"=>"One of your item(s) has already been processed.","responseBody"=>null));
            }
        }
    }
    public function customerChangePassword($data,$c_id)
    {
        $validate = $this->validate($data,array(
                            'oldPassword'=>'required',
                            'newPassword'=>'required|min:8',
                            'confirmPassword'=>'required|matches:newPassword'
                        ),
                        array('confirmPassword'=>'Confirm password','oldPassword'=>'Current Password'));
        if($validate['error'])
        {
            return json_encode(array('responseCode'=>13,'responseMessage'=>$validate['messages'][0]));
        }
        $data['username']  = $c_id;
        $algo              = new AESAlgo();
//        $encryptedOldPassword = $algo->encryptString($data['oldPassword'],$data['username']);
        $encryptedNewPassword = $algo->encryptString($data['newPassword'],$data['username']);
        $sql = "SELECT password FROM userdata_customer WHERE username = '$data[username]' LIMIT 1";
        $result = $this->db_query($sql);
        $encryptedOldPassword = $result[0]['password'];
        $decryptedOldPassword = $algo->decryptString($result[0]['password'],$data['username']);
        if($decryptedOldPassword == $data['oldPassword'])
        {
            $query_data = "UPDATE userdata_customer set password='$encryptedNewPassword', passchg_logon = '0' where username= '$data[username]'";
            $result_data = $this->db_query($query_data,false);
            if($result_data > 0)
            {
                return json_encode(array('responseCode'=>0,'responseMessage'=>'Password changed successfully'));
            }else
            {
                return json_encode(array('responseCode'=>44,'responseMessage'=>'Unable to change password'));
            }
        }
        else
        {
             return json_encode(array('responseCode'=>455,'responseMessage'=>'current password is invalid'));
        }
    }
    
    
    public function passwordChange($data)
    {
            $validationObj  = new validation();
            $validation = $validationObj->validate($data,
                        array(
                            'username'=>'required',
                            'current_password'=>'required',
                            'password'=>'required|min:6',
                            'confirm_password'=>'required|matches:password'
                        ),
                        array('confirm_password'=>'Confirm password','current_password'=>'Current Password')
                       );
           if($data[current_password] == $data[password])
           {
               $validation['error'] = true;
               $validation['messages'][0] = "Kindly choose a password that is different from your current one.";
           }
            if(!$validation['error'])
            {
                $username           = $data['username'];
                $user_password      = $data['password'];
                $user_curr_password = $data['current_password'];
                
                $desencrypt = new DESEncryption();
                $key = $username;
                $cipher_password = $desencrypt->des($key, $user_curr_password, 1, 0, null,null);
                $str_cipher_password = $desencrypt->stringToHex ($cipher_password);
//                $str_cipher_password = $this->EncryptData($username,$user_password);
                $sql = "SELECT username FROM userdata_customer WHERE username = '$username' AND password = '$str_cipher_password'";
                $rr  = $this->db_query($sql,false);
                if($rr == 1)
                {
                    
                    $cipher_password     = $desencrypt->des($key, $user_password, 1, 0, null,null);
                    $str_cipher_password = $desencrypt->stringToHex ($cipher_password);
                    $query_data = "UPDATE userdata_customer set password='$str_cipher_password', passchg_logon = '0' where username= '$username'";
//                    echo $query_data;
                    $result_data = $this->db_query($query_data,false);
                    if($result_data > 0)
                    {
                        if($data['page'] == 'first_login')
                        {
                            return json_encode(array('responseCode'=>0,'responseMessage'=>'Your password was changed successfully... <a href="index.html">Proceed to login</a>'));
                        }
                        else
                        {
                            return json_encode(array('responseCode'=>0,'responseMessage'=>'Your password was changed successfully... logging you out'));
                        }
                        
                    }
                    else
                    {
                        return json_encode(array('responseCode'=>45,'responseMessage'=>'Your password could not be changed'));
                    }
                }else
                {
                    return json_encode(array('responseCode'=>455,'responseMessage'=>'current password is invalid'));
                }

                
            }
        else
        {
            return json_encode(array("responseCode"=>20,"responseMessage"=>$validation['messages'][0]));
        }
	}
    public function verifyToken()
    {
        $token           = $this->getBearerToken();
        try
        {
           $payload      = (new JWT($this->tokenSecretKey, 'HS512'))->decode($token);
           $expire_time  = $payload['exp'];
           $browserAgent = $payload['browser_agent'];
           if(time() >= $expire_time)
           {
               return array("responseCode"=>"z300","responseMessage"=>"Token has expired");
           }
           elseif($_SERVER['HTTP_USER_AGENT'] != $browserAgent)
           {
                return array("responseCode"=>"z300","responseMessage"=>"Fraudulent request from client.");
           }
           else
           {
               $customerRecord = $this->setCustomerRecord($payload);
               return array("responseCode"=>0,"responseMessage"=>"OK","responseBody"=>array("customerRecord"=>$customerRecord));
           }
        }
        catch(Exception $e)
        {
            return array("responseCode"=>"z300","responseMessage"=>$e->getMessage());
        }
    }
    public function generateLinkToken()
    {
        $chars = "123456789abcdefghijklmnopqrstuvwxyz";
        $res = "";
        for ($i = 0; $i < 15; $i++) 
        {
            $res .= $chars[mt_rand(0, strlen($chars)-1)];
        }
        return base64_encode($res);
    }
    public function generateEmailVerificationToken()
    {
        $chars = "1234567890";
        $res = "";
        for ($i = 0; $i < 7; $i++) 
        {
            $res .= $chars[mt_rand(0, strlen($chars)-1)];
        }
        return $res;
    }
    public function setCustomerRecord($payload)
    {
        return array('firstname'=>$payload['firstname'],'username'=>$payload['username'],'lastname'=>$payload['lastname']);
    }
    public function generateToken($data,$tokenType)
    {
        $currentTime  = time();
        $timeDuration = 6000;
        $time  = ($tokenType == "new")?$currentTime+$timeDuration:$currentTime-$timeDuration;
        $payload = array(
                'username'      => $data['username'],
                'firstname'     => $data['firstname'],
                'lastname'      => $data['lastname'],
                'browser_agent' => $_SERVER['HTTP_USER_AGENT'],
                'isat'          => time(),
                'exp'           => $time
            );
        return (new JWT($this->tokenSecretKey, 'HS512', $timeDuration))->encode($payload);
    }
    
    
    
    public function logTransaction()
    {
          $trans_id         = date("Ymdhis");
          $posted_ip        = $_SERVER['REMOTE_ADDR'];
          $total_fare       = $this->getTotalAmount();
          $merchant_id      = $this->merchant_id;
          $t_fare           = $total_fare + $this->charge_fee;
          file_put_contents("ballerz.txt",$merchant_id);
          $payment_mode     = "CARD";
          $trans_type       = "FLIGHT BOOKING"; 
          $response_code    = 99; 
          $response_message = "Initialized";
           $sql              = "INSERT INTO app_transaction_table (transaction_id,transaction_amount,source_acct,destination_acct,trans_type,transaction_desc,response_code,payment_mode,posted_ip,response_message,created,merchant_payment_reference,merchant_id) VALUES ('$trans_id','$t_fare','$merchant_id','FOSHIZI TOURS','$trans_type','Flight Booking reservation for $merchant_id ','$response_code','$payment_mode','$posted_ip','$response_message',NOW(),'$this->merchantPaymentReference','$merchant_id')";

          file_put_contents("bullshit.txt",$sql);
          $result     = $dbobject->db_query($sql,false);
    }
    public function priceCalculator()
    {
        // when a cart item is sent for checkout, calculate the shipping fee, log the cart items to order table and shipping fee to transaction table
    }
    
    public function updateCartBasket()
    {
        // to update the cart, send the transaction id to API, thjj
    }
    public function requery($merchant_id,$transid)
    {
            $curl = curl_init();
            $data = "MerchantRegID=".$merchant_id."&MerchantTransID=".$transid;
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://www.onepay.com.ng/api/ValidateTrans/getTrans.php",
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_POSTREDIR => 3,
              CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POSTFIELDS =>$data, 
              CURLOPT_CUSTOMREQUEST => "POST"
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) 
            {
              return "cURL Error #:" . $err;
            } else 
            {
              return $response;
            }
    }
    
  
    /** 
     * Get header Authorization
     * */
    public function getAuthorizationHeader(){
        $headers = null;
        if (isset($_SERVER['Authorization'])) {
            $headers = trim($_SERVER["Authorization"]);
        }
        else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { //Nginx or fast CGI
            $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
        } elseif (function_exists('apache_request_headers')) {
            $requestHeaders = apache_request_headers();
            // Server-side fix for bug in old Android versions (a nice side-effect of this fix means we don't care about capitalization for Authorization)
            $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
//            print_r($requestHeaders);
            if (isset($requestHeaders['Authorization'])) {
                $headers = trim($requestHeaders['Authorization']);
            }
        }
        return $headers;
    }
    /**
     * get access token from header
     * */
    public function getBearerToken() {
        $headers = $this->getAuthorizationHeader();
//        var_dump($headers);
        // HEADER: Get the access token from the header
        if (!empty($headers)) {
            if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                return $matches[1];
            }
        }
        return null;
    }
  
}