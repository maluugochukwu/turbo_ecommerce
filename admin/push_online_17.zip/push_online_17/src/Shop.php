<?php

use Curl\Curl;

class Shop extends Curl
{
    // private $base_
    public $base_url = 'https://www.store200.com/api/v1';
    private $app_url = 'https://www.store200.com/api/v1/app';
    private $customer_url = 'https://www.store200.com/api/v1/customer';
    private $customer_action_url = 'https://www.store200.com/api/v1/customer/action';
    public $base_img_url = 'https://www.store200.com/admin/';

    private $applicationID = "pub_tk-7D79H7K%R?ST&F=4IIFTYC4ID82XA5S@MZ&";

    public $response_code;
    public $response_body;
    public $response_message;
    public $total_records;
    public $filter;

    public $onepay_vuvaa_merchant_id = "ACC-OPMHT000000248";
    private $merchantID = "VUV-092109351920";

    private $transaction_id;

    public function __construct()
    {
        parent::__construct();
        $this->setHeader('x-application-id', $this->applicationID);
        $this->setHeader('x-merchant-id', $this->merchantID);
    }

    public function loadSettings()
    {
        $this->post($this->app_url . '/loadSettings');

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['merchantInfo']['groupedCategories'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function merchants($data)
    {
        $this->post($this->app_url . '/getMerchants', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['merchants'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function categories($data)
    {
        $this->post($this->base_url . '/merchant/getCategories', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['categories'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function products($data)
    {
        $this->post($this->base_url . '/merchant/getProducts', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['products'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function merchantID($data)
    {
        $this->post($this->app_url . '/getMerchantID', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['merchantID'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function getCategory($data)
    {

        $this->post($this->app_url . '/merchant/getCategoryDetails', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }
    public function verifyPayment($data)
    {
        $this->post($this->app_url. '/verifyPayment', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true);

        $this->response_code = json_decode(json_encode((array)$this->response), true);

        return $this->response_body;
    }

    public function getSubCategory($data)
    {

        $this->post($this->app_url . '/merchant/getSubcategoryDetails', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function featuredProducts($data)
    {
        $this->post($this->app_url . '/getFeaturedProducts', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['featuredProducts'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function productDetails($data)
    {
        $this->post($this->base_url . '/merchant/getProductsDetails', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true);

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function merchantDetails()
    {
        $this->post($this->base_url . '/merchant/merchantDetails');

        return (array)$this->response;
    }

    public function merchantPageSettings()
    {
        $this->post($this->base_url . '/merchant/merchantDetails');

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['pageSettings'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return [
            'primary_color' => $this->response_body['primaryColor'],
            'secondary_color' => $this->response_body['secondaryColor'],
            'menu_font_color' => $this->response_body['menuFontColor'],
            'logo_width' => $this->response_body['logoWidth'],
            'inline_text_logo' => $this->response_body['inlineTextLogo'],
            'show_merchant_name' => $this->response_body['showMerchantName'],
        ];
    }

    public function brands()
    {
        $this->post($this->base_url . '/merchant/getBrands');

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['brands'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function searchAllProducts($data)
    {
        $this->post($this->app_url . '/productSearch', $data);

        $this->total_records = json_decode(json_encode((array)$this->response), true)['responseBody']['totalRecords'];

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['products'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function getStates()
    {
        $this->post($this->app_url . '/getStates');

        return (array)$this->response;
    }

    public function getLgas($data)
    {
        $this->post($this->app_url . '/getLga', $data);

        return (array)$this->response;
    }

    public function searchMerchantProducts($data)
    {
        $this->post($this->base_url . '/merchant/productSearch', $data);

        $this->total_records = json_decode(json_encode((array)$this->response), true)['responseBody']['totalRecords'];

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['products'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function registerUser($data)
    {
        $this->post($this->customer_url . '/customerRegistration', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseMessage'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function verifyEmailLink($data)
    {
        $this->post($this->customer_url . '/verifyEmailLink', $data);

        return (array)$this->response;
    }

    public function checkAccountVerificationStatus($data)
    {
        $this->post($this->customer_url . "/emailVerificationStatus", $data);
        return (array)$this->response;
    }

    public function resetPassword($data)
    {
        $this->post($this->customer_url . '/resetPassword', $data);

        return (array)$this->response;
    }

    public function verifyPasswordLink($data)
    {
        $this->post($this->customer_url . '/verifyPasswordLink', $data);

        return (array)$this->response;
    }

    public function doResetPassword($data)
    {
        $this->post($this->customer_url . '/doResetPassword', $data);

        return (array)$this->response;
    }

    public function loginUser($data)
    {
        $this->post($this->customer_url . '/doLogin', $data);

        return (array)$this->response;
    }

    public function viewProfile()
    {
        $this->post($this->customer_action_url . '/viewProfile');

        return (array)$this->response;
    }

    public function viewAddress($data)
    {
        $this->post($this->customer_action_url . '/viewAddress', $data);

        return (array)$this->response;
    }

    public function addAddress($data)
    {
        $this->post($this->customer_action_url . '/addAddress', $data);

        return (array)$this->response;
    }

    public function editAddress($data)
    {
        $this->post($this->customer_action_url . '/editAddress', $data);

        return (array)$this->response;
    }

    public function profileChangePassword($data)
    {
        $this->post($this->customer_action_url . '/changePassword', $data);

        return (array)$this->response;
    }

    public function updateUserProfile($data)
    {
        $this->post($this->customer_action_url . '/updateProfile', $data);

        return (array)$this->response;
    }

    public function deleteUserAddress($data)
    {
        $this->post($this->customer_action_url . '/deleteAddress', $data);

        return (array)$this->response;
    }

    public function verifyToken()
    {
        $this->post($this->customer_url . '/verifyToken');

        return (array)$this->response;
    }

    public function logOutUser()
    {
        $this->post($this->customer_action_url . '/logout');

        return (array)$this->response;
    }

    public function checkUrl($url)
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($ch);
        $headers = curl_getinfo($ch);
        curl_close($ch);

        return $headers['http_code'];
    }

    public function uriExplode($uri)
    {
        $uri_data = explode('/', $uri);

        return $uri_data;
    }

    public function cleanImageUrl($image)
    {
//        $clean_img_url = $this->base_img_url . preg_replace('/.\//', '', $image, 1);
        // $is_img_ok = $this->checkUrl($clean_img_url);

        // if ($is_img_ok == 200) {
        return $image;
        // } else {
        // return 'images/placeholder.jpg';
        // }
    }

    public function filter($pageNo = 1, $recordsPerRequest = 10, $filter = [])
    {
        if (count($filter) < 1) {
            $this->filter = json_encode([
                "pageNo" => $pageNo,
                "recordsPerRequest" => $recordsPerRequest,
            ]);
        } else {
            $this->filter = json_encode([
                "pageNo" => $pageNo,
                "recordsPerRequest" => $recordsPerRequest,
                "filter" => $filter
            ]);
        }

        return $this->filter;
    }

    public function merchantFilter($merchantName)
    {
        $this->filter = json_encode([
            "merchantName" => $merchantName,
        ]);

        return $this->filter;
    }

    public function productDetailFilter($id)
    {
        $this->filter = json_encode([
            "id" => $id,
        ]);

        return $this->filter;
    }

    public function productSearchFilter($string, $pageNo = 1, $recordsPerRequest = 10)
    {
        $this->filter = json_encode([
            "searchString" => $string,
            "pageNo" => $pageNo,
            "recordsPerRequest" => $recordsPerRequest
        ]);

        return $this->filter;
    }

    public function generateId()
    {
        return $this->transaction_id = rand(0000, 9999);
    }

    function requery($merchant_id, $transid)
    {
        $curl = curl_init();
        $data = 'MerchantRegID=' . $merchant_id . '&MerchantTransID=' . $transid;
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://www.onepay.com.ng/api/ValidateTrans/getTrans.php',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_POSTREDIR => 3,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_CUSTOMREQUEST => 'POST',
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return 'cURL Error #:' . $err;
        } else {
            return $response;
        }
    }

    public function getPickupStations($data)
    {
        $this->post($this->base_url . '/merchant/getPickupStation', $data);

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['pickupStation'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function pickupFilter($state, $lga)
    {
        $this->filter = json_encode([
            "state" => $state,
            "lga" => $lga,
        ]);

        return $this->filter;
    }

    public function banner()
    {
        $this->post($this->app_url . '/getBanner');

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function getSpecialOffers()
    {
        $this->post($this->app_url . '/getSpecialOffer');

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function getBestSellers()
    {
        $this->post($this->app_url . '/bestSellers');

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function logTransaction($data)
    {
        $this->post($this->customer_action_url . '/logTransaction', $data);

        return (array)$this->response;
    }

    public function sendVerificationToken($data)
    {
        $this->post($this->base_url . '/customer/sendAccountVerificationToken', $data);

        return (array)$this->response;
    }

    public function verifyCart($data)
    {
        $this->post($this->base_url . '/merchant/verifyCart', $data);

        return $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];
    }

    public function variantFilter($id, $variant = [])
    {
        $this->filter = json_encode([
            "id" => $id,
            "variant" => [$variant]
        ]);

        return $this->filter;
    }

    public function couponFilter($filter)
    {
        $this->filter = json_encode([
            "couponCode" => $filter,
        ]);

        return $this->filter;
    }

    public function customerLogTransactionFilter($addressID, $coupon, $transaction_id, $delivery_method, $pickupID)
    {
        if ($transaction_id == null) $transaction_id = rand();

        $this->filter = [
            "addressID" => $addressID,
            "coupon" => $coupon,
            "transactionID" => $transaction_id,
            "deliveryMethod" => $delivery_method,
            "pickupStation" => $pickupID
        ];

        return $this->filter;
    }

    public function viewCoupons()
    {
        $this->post($this->customer_action_url . '/viewCoupons');

        return (array)$this->response;
    }

    public function getCouponValue($data)
    {
        $this->post($this->customer_action_url . '/getCouponValue',$data);

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        $this->response_message = json_decode(json_encode((array)$this->response), true)['responseMessage'];

        return $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody'];
    }

    public function viewOrders($data)
    {
        $this->post($this->customer_action_url . '/viewOrders', $data);

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody'];
    }

    public function slider()
    {
        $this->post($this->app_url . '/loadSettings');

        $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody']['merchantInfo']['adverts'];

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        return $this->response_body;
    }

    public function packProductnVariant($cart, $variant = [])
    {
        $cart_filter = [];
        $variant_arr = [];
        foreach ($cart as $myCart) {
            if (isset($myCart["variantData"]) && $myCart["variantData"] !== "") {
                $variant = [
                    "id" => $myCart['variantData']['id'],
                    "quantity" => $myCart['quantity']
                ];
                array_push($variant_arr, $variant);
            } else {
                $variant_arr = [];
            }
            $filter = [
                "id" => $myCart['id'],
                "quantity" => $myCart['quantity'],
                "variant" => $variant_arr
            ];
            array_push($cart_filter, $filter);
        }

        return $cart_filter;
    }

    public function deliveryFee($data)
    {
        $this->post($this->base_url . '/merchant/getDeliveryFee', $data);

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        $this->response_message = json_decode(json_encode((array)$this->response), true)['responseMessage'];

        return $this->response_body = json_decode(json_encode((array)$this->response), true)['responseBody'];
    }

    public function setPrimaryAddress($data)
    {
        $this->post($this->customer_action_url . '/setPrimaryAddress', $data);

        $this->response_code = json_decode(json_encode((array)$this->response), true)['responseCode'];

        $this->response_message = json_decode(json_encode((array)$this->response), true)['responseMessage'];
    }
}
